package com.networkiq.dto;

import lombok.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ForecastDto {
    private Long id;
    private Long storeId;
    private String storeName;
    private Long productId;
    private String productSku;
    private String productName;
    private LocalDate forecastDate;
    private Integer quantity;
    private Double confidenceScore;
}
