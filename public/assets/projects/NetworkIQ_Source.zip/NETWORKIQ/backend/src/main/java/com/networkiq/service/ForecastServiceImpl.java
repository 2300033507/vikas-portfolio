package com.networkiq.service;

import com.networkiq.dto.ForecastDto;
import com.networkiq.model.DemandForecast;
import com.networkiq.model.Inventory;
import com.networkiq.model.Sales;
import com.networkiq.repository.DemandForecastRepository;
import com.networkiq.repository.InventoryRepository;
import com.networkiq.repository.SalesRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ForecastServiceImpl implements ForecastService {

    private final DemandForecastRepository forecastRepository;
    private final InventoryRepository inventoryRepository;
    private final SalesRepository salesRepository;
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${ml.service.url:http://localhost:5000/predict}")
    private String mlServiceUrl;

    @Autowired
    public ForecastServiceImpl(DemandForecastRepository forecastRepository,
                               InventoryRepository inventoryRepository,
                               SalesRepository salesRepository) {
        this.forecastRepository = forecastRepository;
        this.inventoryRepository = inventoryRepository;
        this.salesRepository = salesRepository;
    }

    @Override
    public List<ForecastDto> getAllForecasts() {
        log.info("Fetching all forecasts");
        return forecastRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<ForecastDto> getForecastForStoreAndProduct(Long storeId, Long productId) {
        log.info("Fetching forecasts for store: {} and product: {}", storeId, productId);
        return forecastRepository.findAll().stream()
                .filter(f -> f.getStore().getId().equals(storeId) && f.getProduct().getId().equals(productId))
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void triggerDemandForecast() {
        log.info("Triggering demand forecast optimization...");
        try {
            log.info("Calling ML Service at {}", mlServiceUrl);
            ResponseEntity<String> response = restTemplate.postForEntity(mlServiceUrl, null, String.class);
            log.info("ML Service response: {}", response.getBody());
        } catch (Exception e) {
            log.warn("ML microservice is unreachable ({}) - falling back to database heuristic forecast calculations", e.getMessage());
            runHeuristicForecast();
        }
    }

    private void runHeuristicForecast() {
        log.info("Running rule-based demand forecasting based on historical sales and stock levels");
        List<Inventory> allInventory = inventoryRepository.findAll();
        LocalDate futureDate = LocalDate.now().plusDays(7); // Forecast for next week

        for (Inventory inventory : allInventory) {
            if (inventory.isStore()) {
                List<Sales> salesList = salesRepository.findByStoreAndProduct(inventory.getStore(), inventory.getProduct());
                double avgSales = salesList.stream()
                        .mapToInt(Sales::getQuantity)
                        .average()
                        .orElse(15.0);

                int predictedDemand = (int) Math.round(avgSales * 1.25);
                double confidence = 0.85;

                DemandForecast forecast = forecastRepository.findByStoreAndProductAndForecastDate(
                        inventory.getStore(), inventory.getProduct(), futureDate)
                        .orElse(null);

                if (forecast != null) {
                    forecast.setQuantity(predictedDemand);
                    forecast.setConfidenceScore(confidence);
                    forecastRepository.save(forecast);
                } else {
                    forecastRepository.save(DemandForecast.builder()
                            .store(inventory.getStore())
                            .product(inventory.getProduct())
                            .forecastDate(futureDate)
                            .quantity(predictedDemand)
                            .confidenceScore(confidence)
                            .build());
                }
            }
        }
        log.info("Rule-based demand forecasting completed successfully.");
    }

    private ForecastDto convertToDto(DemandForecast forecast) {
        return ForecastDto.builder()
                .id(forecast.getId())
                .storeId(forecast.getStore().getId())
                .storeName(forecast.getStore().getName())
                .productId(forecast.getProduct().getId())
                .productSku(forecast.getProduct().getSku())
                .productName(forecast.getProduct().getName())
                .forecastDate(forecast.getForecastDate())
                .quantity(forecast.getQuantity())
                .confidenceScore(forecast.getConfidenceScore())
                .build();
    }
}
