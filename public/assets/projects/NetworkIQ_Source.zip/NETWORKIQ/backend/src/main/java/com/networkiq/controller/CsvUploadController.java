package com.networkiq.controller;

import com.networkiq.dto.CsvUploadResponseDto;
import com.networkiq.service.CsvUploadService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/csv")
@Tag(name = "CSV Ingestion", description = "Endpoints for uploading and parsing network location data")
@Slf4j
public class CsvUploadController {

    private final CsvUploadService csvUploadService;

    public CsvUploadController(CsvUploadService csvUploadService) {
        this.csvUploadService = csvUploadService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Upload and parse Indian Store Data CSV", description = "Validates the structure, checks values, deletes duplicates, and seeds stores, products, and inventory items. Restricted to Administrator role.")
    public ResponseEntity<CsvUploadResponseDto> uploadCsv(@RequestParam("file") MultipartFile file) {
        log.info("REST request to upload CSV file: {}", file.getOriginalFilename());
        CsvUploadResponseDto response = csvUploadService.uploadIndianStoreData(file);
        return ResponseEntity.ok(response);
    }
}
