-- Seed Users (passwords are 'admin123' and 'planner123' respectively, encoded with BCrypt)
INSERT INTO users (username, password, email, role, created_at, updated_at) 
VALUES 
('admin', '$2a$10$8.UnVuG9HHgffUDAlk8qCOuy5ErwBi6x3mK6yDSgOFaM69OCs5e5e', 'admin@networkiq.com', 'ROLE_ADMIN', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('planner', '$2a$10$8.UnVuG9HHgffUDAlk8qCOuy5ErwBi6x3mK6yDSgOFaM69OCs5e5e', 'planner@networkiq.com', 'ROLE_PLANNER', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (username) DO NOTHING;

-- Seed Stores (Indian Cities)
INSERT INTO stores (id, name, city, latitude, longitude, capacity, created_at, updated_at)
VALUES
(1, 'Mumbai Retail Store', 'Mumbai', 19.0760, 72.8777, 5000.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 'Delhi Retail Store', 'Delhi', 28.7041, 77.1025, 6000.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(3, 'Bangalore Retail Store', 'Bangalore', 12.9716, 77.5946, 4500.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(4, 'Chennai Retail Store', 'Chennai', 13.0827, 80.2707, 4000.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (id) DO NOTHING;

-- Seed Warehouses
INSERT INTO warehouses (id, name, city, latitude, longitude, capacity, created_at, updated_at)
VALUES
(1, 'West Logistics Hub', 'Mumbai', 19.1663, 73.0119, 50000.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 'North Logistics Hub', 'Delhi', 28.5276, 77.2090, 60000.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (id) DO NOTHING;

-- Seed Products (SKUs)
INSERT INTO products (id, sku, name, category, price, weight, holding_cost, created_at, updated_at)
VALUES
(1, 'PROD-IP15', 'iPhone 15 Pro', 'Electronics', 79900.0, 0.187, 5.5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 'PROD-S24', 'Samsung Galaxy S24 Ultra', 'Electronics', 124900.0, 0.232, 7.5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(3, 'PROD-WH1000', 'Sony WH-1000XM5 Headphones', 'Audio', 29990.0, 0.250, 2.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(4, 'PROD-MBAIR', 'MacBook Air M3', 'Computers', 114900.0, 1.240, 10.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(5, 'PROD-IPAD', 'iPad Pro 11-inch', 'Electronics', 99900.0, 0.444, 8.0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (id) DO NOTHING;

-- Seed Inventory (Store allocations with low/shortage levels)
INSERT INTO inventory (id, store_id, warehouse_id, product_id, stock_quantity, safety_stock, created_at, updated_at)
VALUES
-- Mumbai Store (Low stock on iPhones and Sony headphones)
(1, 1, NULL, 1, 5, 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 1, NULL, 2, 25, 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(3, 1, NULL, 3, 3, 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(4, 1, NULL, 4, 12, 10, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(5, 1, NULL, 5, 15, 10, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- Delhi Store (Shortage of Samsung S24)
(6, 2, NULL, 1, 30, 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(7, 2, NULL, 2, 2, 25, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(8, 2, NULL, 3, 18, 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(9, 2, NULL, 4, 8, 10, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(10, 2, NULL, 5, 4, 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- Bangalore Store (Shortage of MacBook Air M3)
(11, 3, NULL, 1, 22, 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(12, 3, NULL, 2, 18, 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(13, 3, NULL, 3, 20, 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(14, 3, NULL, 4, 1, 12, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(15, 3, NULL, 5, 11, 10, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- West Logistics Hub (Surplus of iPhones and Sony Headphones)
(16, NULL, 1, 1, 250, 50, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(17, NULL, 1, 2, 100, 50, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(18, NULL, 1, 3, 300, 40, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(19, NULL, 1, 4, 80, 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(20, NULL, 1, 5, 120, 30, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- North Logistics Hub (Surplus of Samsung S24 and iPads)
(21, NULL, 2, 1, 150, 50, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(22, NULL, 2, 2, 350, 50, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(23, NULL, 2, 3, 110, 40, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(24, NULL, 2, 4, 75, 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(25, NULL, 2, 5, 280, 30, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (id) DO NOTHING;

-- Seed Sales History (Used by forecast service heuristics)
INSERT INTO sales (store_id, product_id, sale_date, quantity, revenue, created_at)
VALUES
-- Mumbai Store Sales
(1, 1, '2026-08-01', 5, 399500.0, CURRENT_TIMESTAMP),
(1, 1, '2026-08-02', 3, 239700.0, CURRENT_TIMESTAMP),
(1, 1, '2026-08-03', 4, 319600.0, CURRENT_TIMESTAMP),
(1, 1, '2026-08-04', 6, 479400.0, CURRENT_TIMESTAMP),
(1, 1, '2026-08-05', 2, 159800.0, CURRENT_TIMESTAMP),
(1, 1, '2026-08-06', 4, 319600.0, CURRENT_TIMESTAMP),

(1, 3, '2026-08-01', 3, 89970.0, CURRENT_TIMESTAMP),
(1, 3, '2026-08-02', 2, 59980.0, CURRENT_TIMESTAMP),
(1, 3, '2026-08-03', 4, 119960.0, CURRENT_TIMESTAMP),
(1, 3, '2026-08-04', 1, 29990.0, CURRENT_TIMESTAMP),
(1, 3, '2026-08-05', 3, 89970.0, CURRENT_TIMESTAMP),

-- Delhi Store Sales
(2, 2, '2026-08-01', 8, 999200.0, CURRENT_TIMESTAMP),
(2, 2, '2026-08-02', 6, 749400.0, CURRENT_TIMESTAMP),
(2, 2, '2026-08-03', 5, 624500.0, CURRENT_TIMESTAMP),
(2, 2, '2026-08-04', 7, 874300.0, CURRENT_TIMESTAMP),
(2, 2, '2026-08-05', 9, 1124100.0, CURRENT_TIMESTAMP),

-- Bangalore Store Sales
(3, 4, '2026-08-01', 2, 229800.0, CURRENT_TIMESTAMP),
(3, 4, '2026-08-02', 4, 459200.0, CURRENT_TIMESTAMP),
(3, 4, '2026-08-03', 3, 344700.0, CURRENT_TIMESTAMP),
(3, 4, '2026-08-04', 2, 229800.0, CURRENT_TIMESTAMP),
(3, 4, '2026-08-05', 3, 344700.0, CURRENT_TIMESTAMP);

-- Synchronize Auto-Increment Sequences with Manual IDs
SELECT setval('stores_id_seq', COALESCE((SELECT MAX(id) FROM stores), 1));
SELECT setval('warehouses_id_seq', COALESCE((SELECT MAX(id) FROM warehouses), 1));
SELECT setval('products_id_seq', COALESCE((SELECT MAX(id) FROM products), 1));
SELECT setval('inventory_id_seq', COALESCE((SELECT MAX(id) FROM inventory), 1));

