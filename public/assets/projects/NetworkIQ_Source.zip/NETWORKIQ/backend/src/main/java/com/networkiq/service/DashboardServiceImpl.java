package com.networkiq.service;

import com.networkiq.dto.DashboardMetricsDto;
import com.networkiq.model.Inventory;
import com.networkiq.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@Slf4j
public class DashboardServiceImpl implements DashboardService {

    private final StoreRepository storeRepository;
    private final WarehouseRepository warehouseRepository;
    private final ProductRepository productRepository;
    private final InventoryRepository inventoryRepository;
    private final TransferRecommendationRepository recommendationRepository;

    @Autowired
    public DashboardServiceImpl(StoreRepository storeRepository,
                                WarehouseRepository warehouseRepository,
                                ProductRepository productRepository,
                                InventoryRepository inventoryRepository,
                                TransferRecommendationRepository recommendationRepository) {
        this.storeRepository = storeRepository;
        this.warehouseRepository = warehouseRepository;
        this.productRepository = productRepository;
        this.inventoryRepository = inventoryRepository;
        this.recommendationRepository = recommendationRepository;
    }

    @Override
    public DashboardMetricsDto getMetrics() {
        log.info("Calculating dashboard metrics...");
        long totalStores = storeRepository.count();
        long totalWarehouses = warehouseRepository.count();
        long totalSkus = productRepository.count();
        double totalInventoryValue = inventoryRepository.calculateTotalInventoryValue();
        int totalCurrentStock = inventoryRepository.calculateTotalCurrentStock();
        int totalForecastedDemand = 0; // Will be set in demand forecasting module
        
        // Shortage and Excess calculation
        List<Inventory> allInventory = inventoryRepository.findAll();
        int totalShortages = 0;
        int totalExcessStock = 0;
        int standardServiceStockCount = 0;

        for (Inventory inventory : allInventory) {
            int currentStock = inventory.getStockQuantity();
            int safetyStock = inventory.getSafetyStock();
            
            if (currentStock < safetyStock) {
                totalShortages += (safetyStock - currentStock);
            } else {
                totalExcessStock += (currentStock - safetyStock);
                standardServiceStockCount++;
            }
        }

        double serviceLevel = 100.0;
        if (!allInventory.isEmpty()) {
            serviceLevel = ((double) standardServiceStockCount / allInventory.size()) * 100.0;
        }

        long activeRecommendations = recommendationRepository.count();
        double estimatedSavings = recommendationRepository.calculateApprovedSavings() 
                + recommendationRepository.calculatePendingSavings();

        return DashboardMetricsDto.builder()
                .totalStores(totalStores)
                .totalWarehouses(totalWarehouses)
                .totalSkus(totalSkus)
                .totalInventoryValue(totalInventoryValue)
                .totalCurrentStock(totalCurrentStock)
                .totalForecastedDemand(totalForecastedDemand) // Updated dynamically in forecast flow
                .totalShortages(totalShortages)
                .totalExcessStock(totalExcessStock)
                .activeTransferRecommendations(activeRecommendations)
                .estimatedSavings(estimatedSavings)
                .serviceLevel(Math.round(serviceLevel * 100.0) / 100.0)
                .build();
    }
}
