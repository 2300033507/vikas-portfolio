package com.networkiq.service;

import com.networkiq.dto.CsvUploadResponseDto;
import org.springframework.web.multipart.MultipartFile;

public interface CsvUploadService {
    CsvUploadResponseDto uploadIndianStoreData(MultipartFile file);
}
