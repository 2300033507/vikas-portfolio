package com.networkiq.service;

import com.networkiq.dto.TransferDto;
import com.networkiq.exception.BadRequestException;
import com.networkiq.exception.ResourceNotFoundException;
import com.networkiq.model.*;
import com.networkiq.repository.TransferHistoryRepository;
import com.networkiq.repository.TransferRepository;
import com.networkiq.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TransferServiceImpl implements TransferService {

    private final TransferRepository transferRepository;
    private final TransferHistoryRepository transferHistoryRepository;
    private final UserRepository userRepository;

    @Autowired
    public TransferServiceImpl(TransferRepository transferRepository,
                               TransferHistoryRepository transferHistoryRepository,
                               UserRepository userRepository) {
        this.transferRepository = transferRepository;
        this.transferHistoryRepository = transferHistoryRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<TransferDto> getAllTransfers() {
        log.info("Fetching all stock transfers");
        return transferRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<TransferDto> getTransfersByStatus(String status) {
        log.info("Fetching transfers with status: {}", status);
        TransferStatus transferStatus;
        try {
            transferStatus = TransferStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Invalid transfer status. Supported statuses: SCHEDULED, IN_TRANSIT, COMPLETED, CANCELLED.");
        }
        return transferRepository.findByStatus(transferStatus).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<TransferHistory> getTransferHistory(Long transferId) {
        log.info("Fetching audit history for transfer ID: {}", transferId);
        if (!transferRepository.existsById(transferId)) {
            throw new ResourceNotFoundException("Transfer", "id", transferId);
        }
        return transferHistoryRepository.findByTransferIdOrderByCreatedAtDesc(transferId);
    }

    @Override
    @Transactional
    public TransferDto updateTransferStatus(Long transferId, String status, String username) {
        log.info("Updating status for transfer ID: {} to {} by user: {}", transferId, status, username);
        Transfer transfer = transferRepository.findById(transferId)
                .orElseThrow(() -> new ResourceNotFoundException("Transfer", "id", transferId));

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", username));

        TransferStatus newStatus;
        try {
            newStatus = TransferStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Invalid transfer status. Supported statuses: SCHEDULED, IN_TRANSIT, COMPLETED, CANCELLED.");
        }

        // Validate state machine transitions
        TransferStatus currentStatus = transfer.getStatus();
        if (currentStatus == TransferStatus.COMPLETED || currentStatus == TransferStatus.CANCELLED) {
            throw new BadRequestException("Cannot modify status of a completed or cancelled transfer.");
        }

        if (currentStatus == TransferStatus.SCHEDULED && newStatus == TransferStatus.COMPLETED) {
            throw new BadRequestException("Cannot complete scheduled transfer directly without shipping it first.");
        }

        transfer.setStatus(newStatus);
        Transfer saved = transferRepository.save(transfer);

        // Record history log
        transferHistoryRepository.save(TransferHistory.builder()
                .transfer(saved)
                .action(newStatus.name())
                .description("Transfer status changed from " + currentStatus + " to " + newStatus + " by " + username)
                .performedBy(user)
                .build());

        log.info("Transfer ID: {} status updated to {}", transferId, newStatus);
        return convertToDto(saved);
    }

    private TransferDto convertToDto(Transfer transfer) {
        String sourceName = transfer.getSourceStore() != null ? transfer.getSourceStore().getName() : transfer.getSourceWarehouse().getName();
        String destName = transfer.getDestinationStore() != null ? transfer.getDestinationStore().getName() : transfer.getDestinationWarehouse().getName();
        return TransferDto.builder()
                .id(transfer.getId())
                .recommendationId(transfer.getRecommendation() != null ? transfer.getRecommendation().getId() : null)
                .sourceLocationName(sourceName)
                .destinationLocationName(destName)
                .productSku(transfer.getProduct().getSku())
                .productName(transfer.getProduct().getName())
                .quantity(transfer.getQuantity())
                .transferCost(transfer.getTransferCost())
                .status(transfer.getStatus().name())
                .approvedBy(transfer.getApprovedBy().getUsername())
                .approvedAt(transfer.getApprovedAt())
                .createdAt(transfer.getCreatedAt())
                .build();
    }
}
