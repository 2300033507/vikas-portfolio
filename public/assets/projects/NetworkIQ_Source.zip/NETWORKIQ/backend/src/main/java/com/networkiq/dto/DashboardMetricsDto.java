package com.networkiq.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardMetricsDto {
    private Long totalStores;
    private Long totalWarehouses;
    private Long totalSkus;
    private Double totalInventoryValue;
    private Integer totalCurrentStock;
    private Integer totalForecastedDemand;
    private Integer totalShortages;
    private Integer totalExcessStock;
    private Long activeTransferRecommendations;
    private Double estimatedSavings;
    private Double serviceLevel; // percentage value e.g. 95.5
}
