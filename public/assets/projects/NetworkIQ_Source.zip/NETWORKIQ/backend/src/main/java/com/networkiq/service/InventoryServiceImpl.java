package com.networkiq.service;

import com.networkiq.dto.CreateInventoryRequestDto;
import com.networkiq.dto.InventoryDto;
import com.networkiq.dto.UpdateInventoryRequestDto;
import com.networkiq.exception.BadRequestException;
import com.networkiq.exception.ResourceNotFoundException;
import com.networkiq.model.Inventory;
import com.networkiq.model.Product;
import com.networkiq.model.Store;
import com.networkiq.model.Warehouse;
import com.networkiq.repository.InventoryRepository;
import com.networkiq.repository.ProductRepository;
import com.networkiq.repository.StoreRepository;
import com.networkiq.repository.WarehouseRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository inventoryRepository;
    private final StoreRepository storeRepository;
    private final WarehouseRepository warehouseRepository;
    private final ProductRepository productRepository;

    @Autowired
    public InventoryServiceImpl(InventoryRepository inventoryRepository,
                                StoreRepository storeRepository,
                                WarehouseRepository warehouseRepository,
                                ProductRepository productRepository) {
        this.inventoryRepository = inventoryRepository;
        this.storeRepository = storeRepository;
        this.warehouseRepository = warehouseRepository;
        this.productRepository = productRepository;
    }

    @Override
    public List<InventoryDto> getAllInventory() {
        log.info("Fetching all inventory records");
        return inventoryRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public InventoryDto getInventoryById(Long id) {
        log.info("Fetching inventory record by ID: {}", id);
        Inventory inventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory", "id", id));
        return convertToDto(inventory);
    }

    @Override
    public List<InventoryDto> getStoreInventory(Long storeId) {
        log.info("Fetching inventory for store ID: {}", storeId);
        // Ensure store exists
        if (!storeRepository.existsById(storeId)) {
            throw new ResourceNotFoundException("Store", "id", storeId);
        }
        return inventoryRepository.findByStoreId(storeId).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<InventoryDto> getWarehouseInventory(Long warehouseId) {
        log.info("Fetching inventory for warehouse ID: {}", warehouseId);
        // Ensure warehouse exists
        if (!warehouseRepository.existsById(warehouseId)) {
            throw new ResourceNotFoundException("Warehouse", "id", warehouseId);
        }
        return inventoryRepository.findByWarehouseId(warehouseId).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<InventoryDto> getInventoryBySku(String sku) {
        log.info("Fetching inventory for SKU: {}", sku);
        return inventoryRepository.findByProductSku(sku).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<InventoryDto> searchInventory(String sku, String productName, String storeName, String warehouseName) {
        log.info("Searching inventory with parameters: SKU: {}, Product: {}, Store: {}, Warehouse: {}", 
                sku, productName, storeName, warehouseName);
        return inventoryRepository.searchInventory(sku, productName, storeName, warehouseName).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public InventoryDto createInventory(CreateInventoryRequestDto dto) {
        log.info("Creating new inventory record for product: {}", dto.getProductId());
        
        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", dto.getProductId()));

        Store store = null;
        Warehouse warehouse = null;

        if (dto.getStoreId() != null && dto.getWarehouseId() != null) {
            throw new BadRequestException("Inventory record cannot belong to both a Store and a Warehouse simultaneously.");
        }
        if (dto.getStoreId() == null && dto.getWarehouseId() == null) {
            throw new BadRequestException("Inventory record must be linked to either a Store or a Warehouse.");
        }

        if (dto.getStoreId() != null) {
            store = storeRepository.findById(dto.getStoreId())
                    .orElseThrow(() -> new ResourceNotFoundException("Store", "id", dto.getStoreId()));
            
            // Check for existing duplicate records
            if (inventoryRepository.findByStoreAndProduct(store, product).isPresent()) {
                throw new BadRequestException("Inventory record already exists for SKU '" + product.getSku() + "' at Store '" + store.getName() + "'.");
            }
        } else {
            warehouse = warehouseRepository.findById(dto.getWarehouseId())
                    .orElseThrow(() -> new ResourceNotFoundException("Warehouse", "id", dto.getWarehouseId()));
            
            // Check for existing duplicate records
            if (inventoryRepository.findByWarehouseAndProduct(warehouse, product).isPresent()) {
                throw new BadRequestException("Inventory record already exists for SKU '" + product.getSku() + "' at Warehouse '" + warehouse.getName() + "'.");
            }
        }

        Inventory inventory = Inventory.builder()
                .store(store)
                .warehouse(warehouse)
                .product(product)
                .stockQuantity(dto.getStockQuantity())
                .safetyStock(dto.getSafetyStock())
                .build();

        Inventory saved = inventoryRepository.save(inventory);
        log.info("Inventory record successfully created. ID: {}", saved.getId());
        return convertToDto(saved);
    }

    @Override
    @Transactional
    public InventoryDto updateInventory(Long id, UpdateInventoryRequestDto dto) {
        log.info("Updating inventory record ID: {}", id);
        Inventory inventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory", "id", id));

        if (dto.getStockQuantity() != null) {
            inventory.setStockQuantity(dto.getStockQuantity());
        }
        if (dto.getSafetyStock() != null) {
            inventory.setSafetyStock(dto.getSafetyStock());
        }

        Inventory saved = inventoryRepository.save(inventory);
        log.info("Inventory record successfully updated.");
        return convertToDto(saved);
    }

    @Override
    @Transactional
    public void deleteInventory(Long id) {
        log.info("Deleting inventory record ID: {}", id);
        Inventory inventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory", "id", id));
        inventoryRepository.delete(inventory);
        log.info("Inventory record ID: {} successfully deleted.", id);
    }

    private InventoryDto convertToDto(Inventory inventory) {
        int quantity = inventory.getStockQuantity();
        int safetyStock = inventory.getSafetyStock();
        int shortage = Math.max(0, safetyStock - quantity);
        int excess = Math.max(0, quantity - safetyStock);
        double price = inventory.getProduct().getPrice();
        double value = quantity * price;

        Double capacityUtilization = 0.0;
        if (inventory.isStore() && inventory.getStore().getCapacity() > 0) {
            double totalStoreStock = inventoryRepository.findByStoreId(inventory.getStore().getId())
                    .stream().mapToInt(Inventory::getStockQuantity).sum();
            capacityUtilization = (totalStoreStock / inventory.getStore().getCapacity()) * 100.0;
        } else if (inventory.isWarehouse() && inventory.getWarehouse().getCapacity() > 0) {
            double totalWarehouseStock = inventoryRepository.findByWarehouseId(inventory.getWarehouse().getId())
                    .stream().mapToInt(Inventory::getStockQuantity).sum();
            capacityUtilization = (totalWarehouseStock / inventory.getWarehouse().getCapacity()) * 100.0;
        }

        return InventoryDto.builder()
                .id(inventory.getId())
                .storeId(inventory.isStore() ? inventory.getStore().getId() : null)
                .storeName(inventory.isStore() ? inventory.getStore().getName() : null)
                .warehouseId(inventory.isWarehouse() ? inventory.getWarehouse().getId() : null)
                .warehouseName(inventory.isWarehouse() ? inventory.getWarehouse().getName() : null)
                .productId(inventory.getProduct().getId())
                .productSku(inventory.getProduct().getSku())
                .productName(inventory.getProduct().getName())
                .stockQuantity(quantity)
                .safetyStock(safetyStock)
                .shortage(shortage)
                .excess(excess)
                .capacityUtilization(Math.round(capacityUtilization * 100.0) / 100.0)
                .inventoryValue(value)
                .build();
    }
}
