package com.networkiq.repository;

import com.networkiq.model.TransferRecommendation;
import com.networkiq.model.RecommendationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TransferRecommendationRepository extends JpaRepository<TransferRecommendation, Long> {
    List<TransferRecommendation> findByStatus(RecommendationStatus status);

    @Query("SELECT COALESCE(SUM(r.expectedProfit), 0) FROM TransferRecommendation r WHERE r.status = 'APPROVED'")
    Double calculateApprovedSavings();

    @Query("SELECT COALESCE(SUM(r.expectedProfit), 0) FROM TransferRecommendation r WHERE r.status = 'PENDING'")
    Double calculatePendingSavings();
}
