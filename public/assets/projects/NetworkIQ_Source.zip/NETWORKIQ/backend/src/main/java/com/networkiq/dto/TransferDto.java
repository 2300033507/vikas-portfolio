package com.networkiq.dto;

import lombok.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferDto {
    private Long id;
    private Long recommendationId;
    private String sourceLocationName;
    private String destinationLocationName;
    private String productSku;
    private String productName;
    private Integer quantity;
    private Double transferCost;
    private String status;
    private String approvedBy;
    private LocalDateTime approvedAt;
    private LocalDateTime createdAt;
}
