package com.networkiq.controller;

import com.networkiq.dto.TransferDto;
import com.networkiq.model.TransferHistory;
import com.networkiq.service.TransferService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/transfers")
@Tag(name = "Transfers Pipeline", description = "Endpoints for tracking physical stock movements and auditing transaction history")
@Slf4j
public class TransferController {

    private final TransferService transferService;

    public TransferController(TransferService transferService) {
        this.transferService = transferService;
    }

    @GetMapping
    @Operation(summary = "Get all scheduled and completed transfers", description = "Retrieve a summary list of all logistics movements in the network.")
    public ResponseEntity<List<TransferDto>> getAllTransfers() {
        log.info("REST request to fetch all transfers");
        List<TransferDto> transfers = transferService.getAllTransfers();
        return ResponseEntity.ok(transfers);
    }

    @GetMapping("/status")
    @Operation(summary = "Get transfers filtered by status", description = "Query transfers by SCHEDULED, IN_TRANSIT, COMPLETED, or CANCELLED status.")
    public ResponseEntity<List<TransferDto>> getTransfersByStatus(@RequestParam String status) {
        log.info("REST request to fetch transfers by status: {}", status);
        List<TransferDto> transfers = transferService.getTransfersByStatus(status);
        return ResponseEntity.ok(transfers);
    }

    @GetMapping("/{id}/history")
    @Operation(summary = "Get audit logs trail for a specific transfer", description = "Fetch chronological transaction logs showing who moved stock and when.")
    public ResponseEntity<List<TransferHistory>> getTransferHistory(@PathVariable Long id) {
        log.info("REST request to fetch history for transfer ID: {}", id);
        List<TransferHistory> history = transferService.getTransferHistory(id);
        return ResponseEntity.ok(history);
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'PLANNER')")
    @Operation(summary = "Update transfer logistics status", description = "Advance scheduled items to IN_TRANSIT or COMPLETED. Adds an entry in the transaction audit trail.")
    public ResponseEntity<TransferDto> updateTransferStatus(@PathVariable Long id,
                                                             @RequestParam String status,
                                                             Principal principal) {
        String username = principal.getName();
        log.info("REST request by user '{}' to update transfer ID {} status to {}", username, id, status);
        TransferDto updated = transferService.updateTransferStatus(id, status, username);
        return ResponseEntity.ok(updated);
    }
}
