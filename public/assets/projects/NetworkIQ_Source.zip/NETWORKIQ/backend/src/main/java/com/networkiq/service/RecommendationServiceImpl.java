package com.networkiq.service;

import com.networkiq.dto.RecommendationApprovalRequest;
import com.networkiq.dto.RecommendationDto;
import com.networkiq.dto.TransferDto;
import com.networkiq.exception.BadRequestException;
import com.networkiq.exception.ResourceNotFoundException;
import com.networkiq.model.*;
import com.networkiq.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class RecommendationServiceImpl implements RecommendationService {

    private final TransferRecommendationRepository recommendationRepository;
    private final TransferRepository transferRepository;
    private final TransferHistoryRepository transferHistoryRepository;
    private final InventoryRepository inventoryRepository;
    private final UserRepository userRepository;
    private final StoreRepository storeRepository;
    private final WarehouseRepository warehouseRepository;
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${agent.service.url:http://localhost:8000/optimize}")
    private String agentServiceUrl;

    @Autowired
    public RecommendationServiceImpl(TransferRecommendationRepository recommendationRepository,
                                     TransferRepository transferRepository,
                                     TransferHistoryRepository transferHistoryRepository,
                                     InventoryRepository inventoryRepository,
                                     UserRepository userRepository,
                                     StoreRepository storeRepository,
                                     WarehouseRepository warehouseRepository) {
        this.recommendationRepository = recommendationRepository;
        this.transferRepository = transferRepository;
        this.transferHistoryRepository = transferHistoryRepository;
        this.inventoryRepository = inventoryRepository;
        this.userRepository = userRepository;
        this.storeRepository = storeRepository;
        this.warehouseRepository = warehouseRepository;
    }

    @Override
    public List<RecommendationDto> getAllRecommendations() {
        log.info("Fetching all recommendations");
        return recommendationRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<RecommendationDto> getPendingRecommendations() {
        log.info("Fetching all pending recommendations");
        return recommendationRepository.findByStatus(RecommendationStatus.PENDING).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public TransferDto processApproval(Long id, RecommendationApprovalRequest request, String username) {
        log.info("Processing recommendation approval for ID: {}, requested status: {}, quantity: {}", id, request.getStatus(), request.getQuantity());
        TransferRecommendation rec = recommendationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TransferRecommendation", "id", id));

        if (rec.getStatus() != RecommendationStatus.PENDING) {
            throw new BadRequestException("Recommendation has already been processed with status: " + rec.getStatus());
        }

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", username));

        RecommendationStatus newStatus;
        try {
            newStatus = RecommendationStatus.valueOf(request.getStatus().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Invalid status choice. Must be APPROVED or REJECTED");
        }

        int finalQuantity = rec.getQuantity();
        if (request.getQuantity() != null && request.getQuantity() > 0) {
            if (request.getQuantity() > rec.getQuantity()) {
                throw new BadRequestException("Modified transfer quantity cannot exceed recommended amount (" + rec.getQuantity() + ")");
            }
            finalQuantity = request.getQuantity();
            newStatus = RecommendationStatus.MODIFIED;
        }

        rec.setStatus(newStatus);
        rec.setQuantity(finalQuantity);
        recommendationRepository.save(rec);

        if (newStatus == RecommendationStatus.REJECTED) {
            log.info("Recommendation ID: {} was REJECTED by planner: {}", id, username);
            return null;
        }

        // Apply Stock Adjustments for APPROVED/MODIFIED states
        adjustStockLevels(rec, finalQuantity);

        // Schedule Transfer Operation
        Transfer transfer = Transfer.builder()
                .recommendation(rec)
                .sourceStore(rec.getSourceStore())
                .sourceWarehouse(rec.getSourceWarehouse())
                .destinationStore(rec.getDestinationStore())
                .destinationWarehouse(rec.getDestinationWarehouse())
                .product(rec.getProduct())
                .quantity(finalQuantity)
                .transferCost(rec.getTransferCost())
                .status(TransferStatus.SCHEDULED)
                .approvedBy(user)
                .approvedAt(LocalDateTime.now())
                .build();
        
        Transfer savedTransfer = transferRepository.save(transfer);

        // Log transaction history
        transferHistoryRepository.save(TransferHistory.builder()
                .transfer(savedTransfer)
                .action("APPROVED")
                .description("Transfer approved and scheduled for quantity " + finalQuantity + " by " + username)
                .performedBy(user)
                .build());

        log.info("Transfer operation scheduled. ID: {}", savedTransfer.getId());
        return convertToTransferDto(savedTransfer);
    }

    private void adjustStockLevels(TransferRecommendation rec, int quantity) {
        log.info("Executing stock movement: product SKU {}, quantity {}", rec.getProduct().getSku(), quantity);
        
        // 1. Deduct from Source
        if (rec.getSourceStore() != null) {
            Inventory sourceInv = inventoryRepository.findByStoreAndProduct(rec.getSourceStore(), rec.getProduct())
                    .orElseThrow(() -> new BadRequestException("Source store does not have inventory record for this product"));
            if (sourceInv.getStockQuantity() < quantity) {
                throw new BadRequestException("Insufficient stock in source location");
            }
            sourceInv.setStockQuantity(sourceInv.getStockQuantity() - quantity);
            inventoryRepository.save(sourceInv);
        } else if (rec.getSourceWarehouse() != null) {
            Inventory sourceInv = inventoryRepository.findByWarehouseAndProduct(rec.getSourceWarehouse(), rec.getProduct())
                    .orElseThrow(() -> new BadRequestException("Source warehouse does not have inventory record for this product"));
            if (sourceInv.getStockQuantity() < quantity) {
                throw new BadRequestException("Insufficient stock in source location");
            }
            sourceInv.setStockQuantity(sourceInv.getStockQuantity() - quantity);
            inventoryRepository.save(sourceInv);
        }

        // 2. Add to Destination
        if (rec.getDestinationStore() != null) {
            Inventory destInv = inventoryRepository.findByStoreAndProduct(rec.getDestinationStore(), rec.getProduct())
                    .orElseGet(() -> Inventory.builder()
                            .store(rec.getDestinationStore())
                            .product(rec.getProduct())
                            .stockQuantity(0)
                            .safetyStock(0)
                            .build());
            destInv.setStockQuantity(destInv.getStockQuantity() + quantity);
            inventoryRepository.save(destInv);
        } else if (rec.getDestinationWarehouse() != null) {
            Inventory destInv = inventoryRepository.findByWarehouseAndProduct(rec.getDestinationWarehouse(), rec.getProduct())
                    .orElseGet(() -> Inventory.builder()
                            .warehouse(rec.getDestinationWarehouse())
                            .product(rec.getProduct())
                            .stockQuantity(0)
                            .safetyStock(0)
                            .build());
            destInv.setStockQuantity(destInv.getStockQuantity() + quantity);
            inventoryRepository.save(destInv);
        }
    }

    @Override
    @Transactional
    public void triggerMultiAgentOptimization() {
        log.info("Triggering Multi-Agent Optimization Engine...");
        try {
            log.info("Calling Multi-Agent Service at {}", agentServiceUrl);
            ResponseEntity<String> response = restTemplate.postForEntity(agentServiceUrl, null, String.class);
            log.info("Multi-Agent Service response: {}", response.getBody());
        } catch (Exception e) {
            log.warn("Agent microservice is unreachable ({}) - fallback to heuristic calculation rules", e.getMessage());
            runHeuristicOptimization();
        }
    }

    private void runHeuristicOptimization() {
        log.info("Running heuristic optimizer engine matching shortages with surplus stocks...");
        List<Inventory> allInventory = inventoryRepository.findAll();
        List<Inventory> shortages = allInventory.stream()
                .filter(i -> i.getStockQuantity() < i.getSafetyStock())
                .collect(Collectors.toList());
        List<Inventory> surplus = allInventory.stream()
                .filter(i -> i.getStockQuantity() > i.getSafetyStock())
                .collect(Collectors.toList());

        for (Inventory shortInv : shortages) {
            for (Inventory surplusInv : surplus) {
                if (shortInv.getProduct().getId().equals(surplusInv.getProduct().getId())) {
                    int shortageQty = shortInv.getSafetyStock() - shortInv.getStockQuantity();
                    int surplusQty = surplusInv.getStockQuantity() - surplusInv.getSafetyStock();
                    int transferQty = Math.min(shortageQty, surplusQty);

                    if (transferQty > 0) {
                        double lat1 = surplusInv.isStore() ? surplusInv.getStore().getLatitude() : surplusInv.getWarehouse().getLatitude();
                        double lon1 = surplusInv.isStore() ? surplusInv.getStore().getLongitude() : surplusInv.getWarehouse().getLongitude();
                        double lat2 = shortInv.isStore() ? shortInv.getStore().getLatitude() : shortInv.getWarehouse().getLatitude();
                        double lon2 = shortInv.isStore() ? shortInv.getStore().getLongitude() : shortInv.getWarehouse().getLongitude();

                        double distance = calculateDistance(lat1, lon1, lat2, lon2);
                        double weight = shortInv.getProduct().getWeight();
                        double transferCost = distance * weight * 0.15;
                        double expectedProfit = (transferQty * shortInv.getProduct().getPrice() * 0.3) - transferCost;
                        double holdingCostSaved = transferQty * shortInv.getProduct().getHoldingCost() * 4.5;
                        double deliveryImprovement = distance / 80.0;

                        recommendationRepository.save(TransferRecommendation.builder()
                                .sourceStore(surplusInv.isStore() ? surplusInv.getStore() : null)
                                .sourceWarehouse(surplusInv.isWarehouse() ? surplusInv.getWarehouse() : null)
                                .destinationStore(shortInv.isStore() ? shortInv.getStore() : null)
                                .destinationWarehouse(shortInv.isWarehouse() ? shortInv.getWarehouse() : null)
                                .product(shortInv.getProduct())
                                .quantity(transferQty)
                                .transferCost(Math.round(transferCost * 100.0) / 100.0)
                                .expectedProfit(Math.round(expectedProfit * 100.0) / 100.0)
                                .holdingCostSaved(Math.round(holdingCostSaved * 100.0) / 100.0)
                                .deliveryImprovement(Math.round(deliveryImprovement * 10.0) / 10.0)
                                .confidenceScore(0.92)
                                .status(RecommendationStatus.PENDING)
                                .businessReason("SKU shortage resolved at " + shortInv.getLocationName() + " using surplus stocks from " + surplusInv.getLocationName())
                                .reasoning("{\n" +
                                        "  \"demandAgent\": \"Forecasted demand requires safety stock of " + shortInv.getSafetyStock() + " units.\",\n" +
                                        "  \"inventoryAgent\": \"Detected " + shortageQty + " unit shortage at destination and surplus at source.\",\n" +
                                        "  \"transferAgent\": \"Proposed " + transferQty + " units movement.\",\n" +
                                        "  \"costAgent\": \"Est transfer cost: " + Math.round(transferCost) + ". Est Profit: " + Math.round(expectedProfit) + "\",\n" +
                                        "  \"reviewAgent\": \"Sufficient stock remains at source safety levels. Destination capacity limits valid.\"\n" +
                                        "}")
                                .build());

                        surplusInv.setStockQuantity(surplusInv.getStockQuantity() - transferQty);
                        shortInv.setStockQuantity(shortInv.getStockQuantity() + transferQty);
                        break;
                    }
                }
            }
        }
        log.info("Heuristic optimization simulation completed successfully.");
    }

    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        double dist = Math.sin(Math.toRadians(lat1)) * Math.sin(Math.toRadians(lat2))
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.cos(Math.toRadians(theta));
        dist = Math.acos(dist);
        dist = Math.toDegrees(dist);
        dist = dist * 60 * 1.1515 * 1.609344;
        return dist;
    }

    private RecommendationDto convertToDto(TransferRecommendation rec) {
        return RecommendationDto.builder()
                .id(rec.getId())
                .sourceStoreId(rec.getSourceStore() != null ? rec.getSourceStore().getId() : null)
                .sourceStoreName(rec.getSourceStore() != null ? rec.getSourceStore().getName() : null)
                .sourceWarehouseId(rec.getSourceWarehouse() != null ? rec.getSourceWarehouse().getId() : null)
                .sourceWarehouseName(rec.getSourceWarehouse() != null ? rec.getSourceWarehouse().getName() : null)
                .destinationStoreId(rec.getDestinationStore() != null ? rec.getDestinationStore().getId() : null)
                .destinationStoreName(rec.getDestinationStore() != null ? rec.getDestinationStore().getName() : null)
                .destinationWarehouseId(rec.getDestinationWarehouse() != null ? rec.getDestinationWarehouse().getId() : null)
                .destinationWarehouseName(rec.getDestinationWarehouse() != null ? rec.getDestinationWarehouse().getName() : null)
                .productId(rec.getProduct().getId())
                .productSku(rec.getProduct().getSku())
                .productName(rec.getProduct().getName())
                .quantity(rec.getQuantity())
                .transferCost(rec.getTransferCost())
                .expectedProfit(rec.getExpectedProfit())
                .holdingCostSaved(rec.getHoldingCostSaved())
                .deliveryImprovement(rec.getDeliveryImprovement())
                .confidenceScore(rec.getConfidenceScore())
                .status(rec.getStatus().name())
                .businessReason(rec.getBusinessReason())
                .reasoning(rec.getReasoning())
                .createdAt(rec.getCreatedAt())
                .build();
    }

    private TransferDto convertToTransferDto(Transfer transfer) {
        String sourceName = transfer.getSourceStore() != null ? transfer.getSourceStore().getName() : transfer.getSourceWarehouse().getName();
        String destName = transfer.getDestinationStore() != null ? transfer.getDestinationStore().getName() : transfer.getDestinationWarehouse().getName();
        return TransferDto.builder()
                .id(transfer.getId())
                .recommendationId(transfer.getRecommendation() != null ? transfer.getRecommendation().getId() : null)
                .sourceLocationName(sourceName)
                .destinationLocationName(destName)
                .productSku(transfer.getProduct().getSku())
                .productName(transfer.getProduct().getName())
                .quantity(transfer.getQuantity())
                .transferCost(transfer.getTransferCost())
                .status(transfer.getStatus().name())
                .approvedBy(transfer.getApprovedBy().getUsername())
                .approvedAt(transfer.getApprovedAt())
                .createdAt(transfer.getCreatedAt())
                .build();
    }
}
