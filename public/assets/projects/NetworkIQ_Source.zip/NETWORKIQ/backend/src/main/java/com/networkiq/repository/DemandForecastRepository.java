package com.networkiq.repository;

import com.networkiq.model.DemandForecast;
import com.networkiq.model.Product;
import com.networkiq.model.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DemandForecastRepository extends JpaRepository<DemandForecast, Long> {
    List<DemandForecast> findByStoreAndProduct(Store store, Product product);
    Optional<DemandForecast> findByStoreAndProductAndForecastDate(Store store, Product product, LocalDate date);
    
    @Query("SELECT COALESCE(SUM(f.quantity), 0) FROM DemandForecast f")
    Integer calculateTotalForecastedDemand();
}
