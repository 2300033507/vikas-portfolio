package com.networkiq.service;

import com.networkiq.dto.CreateInventoryRequestDto;
import com.networkiq.dto.InventoryDto;
import com.networkiq.dto.UpdateInventoryRequestDto;
import java.util.List;

public interface InventoryService {
    List<InventoryDto> getAllInventory();
    InventoryDto getInventoryById(Long id);
    List<InventoryDto> getStoreInventory(Long storeId);
    List<InventoryDto> getWarehouseInventory(Long warehouseId);
    List<InventoryDto> getInventoryBySku(String sku);
    
    List<InventoryDto> searchInventory(String sku, String productName, String storeName, String warehouseName);

    InventoryDto createInventory(CreateInventoryRequestDto dto);
    InventoryDto updateInventory(Long id, UpdateInventoryRequestDto dto);
    void deleteInventory(Long id);
}
