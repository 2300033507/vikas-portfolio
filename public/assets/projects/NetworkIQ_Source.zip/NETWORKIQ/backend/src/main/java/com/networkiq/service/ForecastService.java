package com.networkiq.service;

import com.networkiq.dto.ForecastDto;
import java.util.List;

public interface ForecastService {
    List<ForecastDto> getAllForecasts();
    List<ForecastDto> getForecastForStoreAndProduct(Long storeId, Long productId);
    void triggerDemandForecast();
}
