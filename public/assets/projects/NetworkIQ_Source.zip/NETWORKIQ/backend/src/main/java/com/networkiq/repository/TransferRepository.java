package com.networkiq.repository;

import com.networkiq.model.Transfer;
import com.networkiq.model.TransferStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TransferRepository extends JpaRepository<Transfer, Long> {
    List<Transfer> findByStatus(TransferStatus status);
}
