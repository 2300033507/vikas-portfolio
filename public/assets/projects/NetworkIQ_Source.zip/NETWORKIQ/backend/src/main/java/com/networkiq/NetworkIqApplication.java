package com.networkiq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetworkIqApplication {
    public static void main(String[] args) {
        SpringApplication.run(NetworkIqApplication.class, args);
    }
}
