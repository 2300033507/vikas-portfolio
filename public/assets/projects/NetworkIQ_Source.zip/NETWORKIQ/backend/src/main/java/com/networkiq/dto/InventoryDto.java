package com.networkiq.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryDto {
    private Long id;
    private Long storeId;
    private String storeName;
    private Long warehouseId;
    private String warehouseName;
    private Long productId;
    private String productSku;
    private String productName;
    private Integer stockQuantity;
    private Integer safetyStock;
    private Integer shortage;
    private Integer excess;
    private Double capacityUtilization;
    private Double inventoryValue;
}
