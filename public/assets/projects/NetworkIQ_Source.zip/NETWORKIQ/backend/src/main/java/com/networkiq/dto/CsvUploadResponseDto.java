package com.networkiq.dto;

import lombok.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CsvUploadResponseDto {
    private Integer totalRecords;
    private Integer imported;
    private Integer failed;
    private List<String> errors;
}
