package com.networkiq.service;

import com.networkiq.dto.LoginRequest;
import com.networkiq.dto.LoginResponse;
import com.networkiq.dto.RegisterRequest;
import com.networkiq.model.User;

public interface UserService {
    LoginResponse authenticateUser(LoginRequest loginRequest);
    User registerUser(RegisterRequest registerRequest);
    void seedAdminUser();
}
