package com.networkiq.service;

import com.networkiq.dto.CsvUploadResponseDto;
import com.networkiq.exception.BadRequestException;
import com.networkiq.model.Inventory;
import com.networkiq.model.Product;
import com.networkiq.model.Store;
import com.networkiq.repository.InventoryRepository;
import com.networkiq.repository.ProductRepository;
import com.networkiq.repository.StoreRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Slf4j
public class CsvUploadServiceImpl implements CsvUploadService {

    private final StoreRepository storeRepository;
    private final ProductRepository productRepository;
    private final InventoryRepository inventoryRepository;

    @Autowired
    public CsvUploadServiceImpl(StoreRepository storeRepository,
                                ProductRepository productRepository,
                                InventoryRepository inventoryRepository) {
        this.storeRepository = storeRepository;
        this.productRepository = productRepository;
        this.inventoryRepository = inventoryRepository;
    }

    @Override
    @Transactional
    public CsvUploadResponseDto uploadIndianStoreData(MultipartFile file) {
        log.info("Starting CSV data upload validation and parsing...");
        
        // 1. File Type and Extension Validation
        if (file.isEmpty()) {
            throw new BadRequestException("Uploaded file is empty");
        }
        
        String filename = file.getOriginalFilename();
        if (filename == null || (!filename.endsWith(".csv") && !filename.endsWith(".txt"))) {
            throw new BadRequestException("Invalid file format. Only CSV files (.csv) are supported.");
        }

        int totalRecords = 0;
        int imported = 0;
        int failed = 0;
        List<String> errors = new ArrayList<>();
        Set<String> processedKeys = new HashSet<>();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            String headerLine = reader.readLine();
            if (headerLine == null) {
                throw new BadRequestException("CSV file contains no headers");
            }

            // Clean headers and check columns
            String[] headers = headerLine.toLowerCase().split(",");
            if (headers.length < 13) {
                throw new BadRequestException("Invalid CSV headers. The file must contain at least 13 columns.");
            }

            // Expected headers checklist
            String[] expectedHeaders = {
                "store_name", "city", "latitude", "longitude", "capacity",
                "sku", "product_name", "category", "price", "weight",
                "holding_cost", "stock_quantity", "safety_stock"
            };

            for (String expected : expectedHeaders) {
                boolean found = false;
                for (String header : headers) {
                    if (header.trim().replace("\"", "").equals(expected)) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    throw new BadRequestException("Missing required column header: " + expected);
                }
            }

            String line;
            int lineNumber = 1;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (line.trim().isEmpty()) {
                    continue;
                }

                totalRecords++;
                String[] tokens = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
                if (tokens.length < 13) {
                    failed++;
                    errors.add(String.format("Row %d: Incorrect column count (expected 13+, found %d)", lineNumber, tokens.length));
                    continue;
                }

                try {
                    // Extract and clean values
                    String storeName = cleanToken(tokens[0]);
                    String city = cleanToken(tokens[1]);
                    String latitudeRaw = cleanToken(tokens[2]);
                    String longitudeRaw = cleanToken(tokens[3]);
                    String capacityRaw = cleanToken(tokens[4]);
                    String sku = cleanToken(tokens[5]);
                    String productName = cleanToken(tokens[6]);
                    String category = cleanToken(tokens[7]);
                    String priceRaw = cleanToken(tokens[8]);
                    String weightRaw = cleanToken(tokens[9]);
                    String holdingCostRaw = cleanToken(tokens[10]);
                    String stockRaw = cleanToken(tokens[11]);
                    String safetyRaw = cleanToken(tokens[12]);

                    // 2. Validate missing values
                    if (storeName.isEmpty() || city.isEmpty() || sku.isEmpty() || productName.isEmpty() || category.isEmpty()) {
                        failed++;
                        errors.add(String.format("Row %d: Missing required text attributes (store_name, city, sku, product_name, category cannot be blank)", lineNumber));
                        continue;
                    }

                    // 3. Parse numbers & validate format
                    double latitude = Double.parseDouble(latitudeRaw);
                    double longitude = Double.parseDouble(longitudeRaw);
                    double capacity = Double.parseDouble(capacityRaw);
                    double price = Double.parseDouble(priceRaw);
                    double weight = Double.parseDouble(weightRaw);
                    double holdingCost = Double.parseDouble(holdingCostRaw);
                    int stockQuantity = Integer.parseInt(stockRaw);
                    int safetyStock = Integer.parseInt(safetyRaw);

                    // 4. Validate boundaries
                    if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
                        failed++;
                        errors.add(String.format("Row %d: Geolocation values are out of bounds (Latitude: %s, Longitude: %s)", lineNumber, latitudeRaw, longitudeRaw));
                        continue;
                    }

                    if (capacity < 0 || price < 0 || weight < 0 || holdingCost < 0 || stockQuantity < 0 || safetyStock < 0) {
                        failed++;
                        errors.add(String.format("Row %d: Numeric attributes cannot be negative", lineNumber));
                        continue;
                    }

                    // 5. Deduplicate records within file
                    String uniqueKey = (storeName + ":" + sku).toLowerCase();
                    if (processedKeys.contains(uniqueKey)) {
                        failed++;
                        errors.add(String.format("Row %d: Duplicate record skipped for Store '%s' and SKU '%s'", lineNumber, storeName, sku));
                        continue;
                    }
                    processedKeys.add(uniqueKey);

                    // 6. DB Ingestion
                    // Process Store
                    Store store = storeRepository.findByName(storeName)
                            .orElseGet(() -> storeRepository.save(Store.builder()
                                    .name(storeName)
                                    .city(city)
                                    .latitude(latitude)
                                    .longitude(longitude)
                                    .capacity(capacity)
                                    .build()));

                    // Process Product
                    Product product = productRepository.findBySku(sku)
                            .orElseGet(() -> productRepository.save(Product.builder()
                                    .sku(sku)
                                    .name(productName)
                                    .category(category)
                                    .price(price)
                                    .weight(weight)
                                    .holdingCost(holdingCost)
                                    .build()));

                    // Process Inventory
                    Inventory inventory = inventoryRepository.findByStoreAndProduct(store, product)
                            .orElse(null);

                    if (inventory != null) {
                        inventory.setStockQuantity(stockQuantity);
                        inventory.setSafetyStock(safetyStock);
                        inventoryRepository.save(inventory);
                    } else {
                        inventoryRepository.save(Inventory.builder()
                                .store(store)
                                .product(product)
                                .stockQuantity(stockQuantity)
                                .safetyStock(safetyStock)
                                .build());
                    }

                    imported++;

                } catch (NumberFormatException e) {
                    failed++;
                    errors.add(String.format("Row %d: Number format conversion error (%s)", lineNumber, e.getMessage()));
                } catch (Exception e) {
                    failed++;
                    errors.add(String.format("Row %d: Ingestion failed (%s)", lineNumber, e.getMessage()));
                }
            }

        } catch (BadRequestException bre) {
            throw bre;
        } catch (Exception e) {
            log.error("CSV Ingestion Error", e);
            throw new BadRequestException("CSV ingestion process failed: " + e.getMessage());
        }

        log.info("CSV Processed: Total: {}, Imported: {}, Failed: {}", totalRecords, imported, failed);
        return CsvUploadResponseDto.builder()
                .totalRecords(totalRecords)
                .imported(imported)
                .failed(failed)
                .errors(errors)
                .build();
    }

    private String cleanToken(String token) {
        if (token == null) return "";
        String trimmed = token.trim();
        if (trimmed.startsWith("\"") && trimmed.endsWith("\"")) {
            trimmed = trimmed.substring(1, trimmed.length() - 1);
        }
        return trimmed.trim();
    }
}
