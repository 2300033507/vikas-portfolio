package com.networkiq.controller;

import com.networkiq.dto.DashboardMetricsDto;
import com.networkiq.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
@Tag(name = "Dashboard", description = "Endpoints for retrieving system metrics and KPIs")
@Slf4j
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping("/metrics")
    @Operation(summary = "Get supply chain dashboard metrics", description = "Aggregates inventory counts, forecasts, values, active recommendations, estimated savings, and calculated service levels.")
    public ResponseEntity<DashboardMetricsDto> getMetrics() {
        log.info("REST request to retrieve dashboard metrics");
        DashboardMetricsDto metrics = dashboardService.getMetrics();
        return ResponseEntity.ok(metrics);
    }
}
