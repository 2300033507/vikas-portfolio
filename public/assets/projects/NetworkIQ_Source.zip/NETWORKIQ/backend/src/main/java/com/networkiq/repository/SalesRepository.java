package com.networkiq.repository;

import com.networkiq.model.Product;
import com.networkiq.model.Sales;
import com.networkiq.model.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface SalesRepository extends JpaRepository<Sales, Long> {
    List<Sales> findByStoreAndProduct(Store store, Product product);
    List<Sales> findByStoreIdAndProductIdAndSaleDateBetween(Long storeId, Long productId, LocalDate startDate, LocalDate endDate);
}
