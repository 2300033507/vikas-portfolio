package com.networkiq.controller;

import com.networkiq.dto.CreateInventoryRequestDto;
import com.networkiq.dto.InventoryDto;
import com.networkiq.dto.UpdateInventoryRequestDto;
import com.networkiq.service.InventoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@Tag(name = "Inventory", description = "Endpoints for managing store and warehouse inventory levels")
@Slf4j
public class InventoryController {

    private final InventoryService inventoryService;

    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @GetMapping
    @Operation(summary = "Get all inventory items", description = "Returns a list of all SKU stock quantities, safety stocks, shortages, excesses, values, and capacity utilizations across the retail network.")
    public ResponseEntity<List<InventoryDto>> getAllInventory() {
        log.info("REST request to fetch all inventory");
        List<InventoryDto> inventory = inventoryService.getAllInventory();
        return ResponseEntity.ok(inventory);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get an inventory record by database ID", description = "Fetch a single inventory details record.")
    public ResponseEntity<InventoryDto> getInventoryById(@PathVariable Long id) {
        log.info("REST request to fetch inventory record by ID: {}", id);
        InventoryDto inventory = inventoryService.getInventoryById(id);
        return ResponseEntity.ok(inventory);
    }

    @GetMapping("/store/{storeId}")
    @Operation(summary = "Get inventory for a specific store", description = "Filter inventory by store database ID.")
    public ResponseEntity<List<InventoryDto>> getStoreInventory(@PathVariable Long storeId) {
        log.info("REST request to fetch inventory for store: {}", storeId);
        List<InventoryDto> inventory = inventoryService.getStoreInventory(storeId);
        return ResponseEntity.ok(inventory);
    }

    @GetMapping("/warehouse/{warehouseId}")
    @Operation(summary = "Get inventory for a specific warehouse", description = "Filter inventory by warehouse database ID.")
    public ResponseEntity<List<InventoryDto>> getWarehouseInventory(@PathVariable Long warehouseId) {
        log.info("REST request to fetch inventory for warehouse: {}", warehouseId);
        List<InventoryDto> inventory = inventoryService.getWarehouseInventory(warehouseId);
        return ResponseEntity.ok(inventory);
    }

    @GetMapping("/sku/{sku}")
    @Operation(summary = "Get inventory for a specific SKU", description = "Filter stock placements across all network locations by SKU code.")
    public ResponseEntity<List<InventoryDto>> getInventoryBySku(@PathVariable String sku) {
        log.info("REST request to fetch inventory for SKU: {}", sku);
        List<InventoryDto> inventory = inventoryService.getInventoryBySku(sku);
        return ResponseEntity.ok(inventory);
    }

    @GetMapping("/search")
    @Operation(summary = "Search and filter stock dynamically", description = "Filter inventory records by SKU, product name, store name, or warehouse name matches.")
    public ResponseEntity<List<InventoryDto>> searchInventory(@RequestParam(required = false) String sku,
                                                             @RequestParam(required = false) String productName,
                                                             @RequestParam(required = false) String storeName,
                                                             @RequestParam(required = false) String warehouseName) {
        log.info("REST request to search inventory. SKU: {}, Prod: {}, Store: {}, Wh: {}", sku, productName, storeName, warehouseName);
        List<InventoryDto> results = inventoryService.searchInventory(sku, productName, storeName, warehouseName);
        return ResponseEntity.ok(results);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Create a new inventory record", description = "Adds a stock mapping for a product at a specific store or warehouse. Restricted to Administrator role.")
    public ResponseEntity<InventoryDto> createInventory(@Valid @RequestBody CreateInventoryRequestDto request) {
        log.info("REST request to create inventory record for product ID: {}", request.getProductId());
        InventoryDto created = inventoryService.createInventory(request);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'PLANNER')")
    @Operation(summary = "Modify stock parameters", description = "Updates stock levels or safety stock thresholds for a location inventory mapping.")
    public ResponseEntity<InventoryDto> updateInventory(@PathVariable Long id,
                                                         @Valid @RequestBody UpdateInventoryRequestDto request) {
        log.info("REST request to update stock parameters for inventory ID: {}", id);
        InventoryDto updated = inventoryService.updateInventory(id, request);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete an inventory record", description = "Completely removes a product stock mapping from a location. Restricted to Administrator role.")
    public ResponseEntity<Void> deleteInventory(@PathVariable Long id) {
        log.info("REST request to delete inventory ID: {}", id);
        inventoryService.deleteInventory(id);
        return ResponseEntity.noContent().build();
    }
}
