package com.networkiq.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecommendationApprovalRequest {
    @NotBlank(message = "Status is required (APPROVED or REJECTED)")
    private String status;

    private Integer quantity; // Optional override quantity for MODIFIED status
}
