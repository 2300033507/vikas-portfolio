package com.networkiq.model;

public enum RecommendationStatus {
    PENDING,
    APPROVED,
    REJECTED,
    MODIFIED
}
