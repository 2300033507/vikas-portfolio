package com.networkiq.service;

import com.networkiq.dto.TransferDto;
import com.networkiq.model.TransferHistory;
import java.util.List;

public interface TransferService {
    List<TransferDto> getAllTransfers();
    List<TransferDto> getTransfersByStatus(String status);
    List<TransferHistory> getTransferHistory(Long transferId);
    TransferDto updateTransferStatus(Long transferId, String status, String username);
}
