package com.networkiq.model;

public enum Role {
    ROLE_ADMIN,
    ROLE_PLANNER
}
