package com.networkiq.controller;

import com.networkiq.dto.RecommendationApprovalRequest;
import com.networkiq.dto.RecommendationDto;
import com.networkiq.dto.TransferDto;
import com.networkiq.service.RecommendationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/recommendations")
@Tag(name = "Recommendations", description = "Endpoints for multi-agent network optimization recommendations and approvals")
@Slf4j
public class RecommendationController {

    private final RecommendationService recommendationService;

    public RecommendationController(RecommendationService recommendationService) {
        this.recommendationService = recommendationService;
    }

    @GetMapping
    @Operation(summary = "Get all stock placement recommendations", description = "Retrieve a listing of all historical and pending transfer recommendations.")
    public ResponseEntity<List<RecommendationDto>> getAllRecommendations() {
        log.info("REST request to fetch all recommendations");
        List<RecommendationDto> recommendations = recommendationService.getAllRecommendations();
        return ResponseEntity.ok(recommendations);
    }

    @GetMapping("/pending")
    @Operation(summary = "Get pending transfer recommendations", description = "Retrieve recommendations awaiting human planner review.")
    public ResponseEntity<List<RecommendationDto>> getPendingRecommendations() {
        log.info("REST request to fetch pending recommendations");
        List<RecommendationDto> recommendations = recommendationService.getPendingRecommendations();
        return ResponseEntity.ok(recommendations);
    }

    @PostMapping("/trigger")
    @PreAuthorize("hasAnyRole('ADMIN', 'PLANNER')")
    @Operation(summary = "Trigger Multi-Agent System Optimization", description = "Calls the LangGraph multi-agent service to calculate optimal SKU transfers. Runs heuristic optimization if service is offline.")
    public ResponseEntity<Map<String, String>> triggerOptimization() {
        log.info("REST request to trigger multi-agent optimization");
        recommendationService.triggerMultiAgentOptimization();
        return ResponseEntity.ok(Map.of(
                "message", "Multi-agent optimization cycle triggered successfully."
        ));
    }

    @PostMapping("/{id}/approve")
    @PreAuthorize("hasAnyRole('ADMIN', 'PLANNER')")
    @Operation(summary = "Approve, Reject, or Modify a pending recommendation", description = "Executes the recommendation. If status is APPROVED or MODIFIED, inventory stock levels are adjusted and a Scheduled Transfer log is registered.")
    public ResponseEntity<TransferDto> approveRecommendation(@PathVariable Long id,
                                                             @Valid @RequestBody RecommendationApprovalRequest request,
                                                             Principal principal) {
        String username = principal.getName();
        log.info("REST request by planner '{}' to process recommendation ID: {} as {}", username, id, request.getStatus());
        TransferDto transferDto = recommendationService.processApproval(id, request, username);
        return ResponseEntity.ok(transferDto);
    }
}
