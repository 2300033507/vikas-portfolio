package com.networkiq.dto;

import lombok.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecommendationDto {
    private Long id;
    private Long sourceStoreId;
    private String sourceStoreName;
    private Long sourceWarehouseId;
    private String sourceWarehouseName;
    private Long destinationStoreId;
    private String destinationStoreName;
    private Long destinationWarehouseId;
    private String destinationWarehouseName;
    private Long productId;
    private String productSku;
    private String productName;
    private Integer quantity;
    private Double transferCost;
    private Double expectedProfit;
    private Double holdingCostSaved;
    private Double deliveryImprovement;
    private Double confidenceScore;
    private String status;
    private String businessReason;
    private String reasoning;
    private LocalDateTime createdAt;
}
