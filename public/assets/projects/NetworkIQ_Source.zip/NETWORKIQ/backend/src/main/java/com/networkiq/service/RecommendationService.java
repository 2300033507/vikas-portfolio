package com.networkiq.service;

import com.networkiq.dto.RecommendationApprovalRequest;
import com.networkiq.dto.RecommendationDto;
import com.networkiq.dto.TransferDto;
import java.util.List;

public interface RecommendationService {
    List<RecommendationDto> getAllRecommendations();
    List<RecommendationDto> getPendingRecommendations();
    TransferDto processApproval(Long id, RecommendationApprovalRequest request, String username);
    void triggerMultiAgentOptimization();
}
