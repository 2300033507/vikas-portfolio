package com.networkiq.model;

public enum TransferStatus {
    SCHEDULED,
    IN_TRANSIT,
    COMPLETED,
    CANCELLED
}
