package com.networkiq.repository;

import com.networkiq.model.Inventory;
import com.networkiq.model.Product;
import com.networkiq.model.Store;
import com.networkiq.model.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    Optional<Inventory> findByStoreAndProduct(Store store, Product product);
    Optional<Inventory> findByWarehouseAndProduct(Warehouse warehouse, Product product);
    List<Inventory> findByStoreId(Long storeId);
    List<Inventory> findByWarehouseId(Long warehouseId);
    List<Inventory> findByProductSku(String sku);

    @Query("SELECT i FROM Inventory i WHERE " +
           "(:sku IS NULL OR LOWER(i.product.sku) LIKE LOWER(CONCAT('%', :sku, '%'))) AND " +
           "(:productName IS NULL OR LOWER(i.product.name) LIKE LOWER(CONCAT('%', :productName, '%'))) AND " +
           "(:storeName IS NULL OR LOWER(i.store.name) LIKE LOWER(CONCAT('%', :storeName, '%'))) AND " +
           "(:warehouseName IS NULL OR LOWER(i.warehouse.name) LIKE LOWER(CONCAT('%', :warehouseName, '%')))")
    List<Inventory> searchInventory(@Param("sku") String sku,
                                    @Param("productName") String productName,
                                    @Param("storeName") String storeName,
                                    @Param("warehouseName") String warehouseName);

    @Query("SELECT COALESCE(SUM(i.stockQuantity * i.product.price), 0) FROM Inventory i")
    Double calculateTotalInventoryValue();

    @Query("SELECT COALESCE(SUM(i.stockQuantity), 0) FROM Inventory i")
    Integer calculateTotalCurrentStock();

    @Query("SELECT COUNT(DISTINCT i.product.id) FROM Inventory i")
    Long countDistinctSkus();
}
