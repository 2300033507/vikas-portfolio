package com.networkiq.controller;

import com.networkiq.dto.ForecastDto;
import com.networkiq.service.ForecastService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/forecast")
@Tag(name = "Demand Forecast", description = "Endpoints for managing demand forecasts")
@Slf4j
public class ForecastController {

    private final ForecastService forecastService;

    public ForecastController(ForecastService forecastService) {
        this.forecastService = forecastService;
    }

    @GetMapping
    @Operation(summary = "Get all demand forecasts", description = "List all demand forecasts stored in the system.")
    public ResponseEntity<List<ForecastDto>> getAllForecasts() {
        log.info("REST request to fetch all forecasts");
        List<ForecastDto> forecasts = forecastService.getAllForecasts();
        return ResponseEntity.ok(forecasts);
    }

    @PostMapping("/trigger")
    @PreAuthorize("hasAnyRole('ADMIN', 'PLANNER')")
    @Operation(summary = "Trigger SKU Demand Forecasting", description = "Calls the XGBoost forecasting service to predict future sales, saving output to the database. Falls back to database heuristics if ML service is unreachable.")
    public ResponseEntity<Map<String, String>> triggerForecast() {
        log.info("REST request to trigger demand forecasting");
        forecastService.triggerDemandForecast();
        return ResponseEntity.ok(Map.of(
                "message", "Demand forecasting triggered and completed successfully."
        ));
    }
}
