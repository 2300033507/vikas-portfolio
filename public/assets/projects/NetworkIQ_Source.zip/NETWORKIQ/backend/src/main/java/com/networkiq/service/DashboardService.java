package com.networkiq.service;

import com.networkiq.dto.DashboardMetricsDto;

public interface DashboardService {
    DashboardMetricsDto getMetrics();
}
