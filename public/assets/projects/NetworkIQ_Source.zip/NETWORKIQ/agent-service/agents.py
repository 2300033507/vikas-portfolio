import os
import json
import logging
import datetime
import math
from typing import TypedDict, List, Dict, Any
from sqlalchemy import create_engine, text
from langgraph.graph import StateGraph, END

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("Multi-Agent-Core")

# Database URL
DB_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/networkiq")

# Helper: Haversine distance
def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    # Radius of earth in km
    R = 6371.0
    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    a = (math.sin(d_lat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(d_lon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

# 1. State Definition
class AgentState(TypedDict):
    # Base Data loaded from DB
    inventory: List[Dict[str, Any]]
    forecasts: List[Dict[str, Any]]
    stores: List[Dict[str, Any]]
    warehouses: List[Dict[str, Any]]
    products: List[Dict[str, Any]]
    
    # Intermediate shared states
    demands: Dict[str, int]               # storeId:productId -> Target Stock Quantity
    shortages: List[Dict[str, Any]]       # SKU placement shortages
    surpluses: List[Dict[str, Any]]       # SKU placement surpluses
    proposals: List[Dict[str, Any]]       # Recommended transfer routes
    capacity_validated: List[Dict[str, Any]]
    costed_proposals: List[Dict[str, Any]]
    final_recommendations: List[Dict[str, Any]]
    
    # Agent logs
    reasoning: Dict[str, str]             # Agent Name -> Reasoning Log

# 2. Agent Node: Demand Agent
def demand_agent_node(state: AgentState) -> Dict[str, Any]:
    logger.info("Executing Demand Agent...")
    demands = {}
    logs = []
    
    # Create target targets based on future forecasted demand (if any) and safety stocks
    for inv in state["inventory"]:
        # Find product forecast for this store
        store_id = inv["store_id"]
        prod_id = inv["product_id"]
        safety = inv["safety_stock"]
        
        if store_id is not None:
            # Check forecasts
            forecast_qty = 0
            for fc in state["forecasts"]:
                if fc["store_id"] == store_id and fc["product_id"] == prod_id:
                    forecast_qty = max(forecast_qty, fc["quantity"])
            
            # Target = safety stock + expected sales forecast
            target_stock = safety + forecast_qty
            key = f"{store_id}:{prod_id}"
            demands[key] = target_stock
            logs.append(f"Store {store_id}, Product {prod_id}: Target stock set to {target_stock} (Safety: {safety}, Forecasted Sales: {forecast_qty})")
            
    reasoning = "Target stocking levels calculated. Used safety stock thresholds combined with predicted demand forecasts to prevent out-of-stock events."
    return {
        "demands": demands,
        "reasoning": {"Demand Agent": reasoning}
    }

# 3. Agent Node: Inventory Agent
def inventory_agent_node(state: AgentState) -> Dict[str, Any]:
    logger.info("Executing Inventory Agent...")
    shortages = []
    surpluses = []
    logs = []

    demands = state["demands"]

    for inv in state["inventory"]:
        store_id = inv["store_id"]
        wh_id = inv["warehouse_id"]
        prod_id = inv["product_id"]
        stock = inv["stock_quantity"]
        safety = inv["safety_stock"]
        
        # Identifier of location
        loc_name = f"Store {store_id}" if store_id is not None else f"Warehouse {wh_id}"
        
        # Check Shortage (dips below safety stock)
        if stock < safety:
            shortage_qty = safety - stock
            shortages.append({
                "store_id": store_id,
                "warehouse_id": wh_id,
                "product_id": prod_id,
                "quantity_needed": shortage_qty,
                "current_stock": stock,
                "safety_stock": safety
            })
            logs.append(f"Shortage flagged at {loc_name} for SKU {prod_id}: deficit of {shortage_qty} units.")
        
        # Check Surplus
        if store_id is not None:
            # Target defined by Demand Agent
            key = f"{store_id}:{prod_id}"
            target = demands.get(key, safety)
            if stock > target:
                surpluses.append({
                    "store_id": store_id,
                    "warehouse_id": None,
                    "product_id": prod_id,
                    "quantity_available": stock - target,
                    "current_stock": stock
                })
        else:
            # Warehouse surplus is anything above warehouse safety threshold (e.g. baseline buffer)
            if stock > safety:
                surpluses.append({
                    "store_id": None,
                    "warehouse_id": wh_id,
                    "product_id": prod_id,
                    "quantity_available": stock - safety,
                    "current_stock": stock
                })

    reasoning = f"Inventory analysis completed. Identified {len(shortages)} shortages and {len(surpluses)} surplus positions across fulfillment network."
    return {
        "shortages": shortages,
        "surpluses": surpluses,
        "reasoning": {"Inventory Agent": reasoning}
    }

# 4. Agent Node: Transfer Agent
def transfer_agent_node(state: AgentState) -> Dict[str, Any]:
    logger.info("Executing Transfer Agent...")
    proposals = []
    
    shortages = state["shortages"]
    surpluses = state["surpluses"]

    # Match deficit and surplus SKU records
    for short in shortages:
        for surplus in surpluses:
            if short["product_id"] == surplus["product_id"]:
                needed = short["quantity_needed"]
                avail = surplus["quantity_available"]
                transfer_qty = min(needed, avail)
                
                if transfer_qty > 0:
                    proposals.append({
                        "source_store_id": surplus["store_id"],
                        "source_warehouse_id": surplus["warehouse_id"],
                        "destination_store_id": short["store_id"],
                        "destination_warehouse_id": short["warehouse_id"],
                        "product_id": short["product_id"],
                        "quantity": transfer_qty
                    })
                    
                    # Update local state counters
                    short["quantity_needed"] -= transfer_qty
                    surplus["quantity_available"] -= transfer_qty

    reasoning = f"Matched supply/demand gaps. Proposed {len(proposals)} physical transfers between surplus repositories and deficit locations."
    return {
        "proposals": proposals,
        "reasoning": {"Transfer Agent": reasoning}
    }

# 5. Agent Node: Capacity Agent
def capacity_agent_node(state: AgentState) -> Dict[str, Any]:
    logger.info("Executing Capacity Agent...")
    capacity_validated = []
    
    # Group proposed transfers by destination store/warehouse
    for prop in state["proposals"]:
        dest_store_id = prop["destination_store_id"]
        dest_wh_id = prop["destination_warehouse_id"]
        qty = prop["quantity"]
        
        capacity = 0.0
        current_total_stock = 0
        
        # Retrieve capacities
        if dest_store_id is not None:
            for store in state["stores"]:
                if store["id"] == dest_store_id:
                    capacity = store["capacity"]
                    break
            current_total_stock = sum(inv["stock_quantity"] for inv in state["inventory"] if inv["store_id"] == dest_store_id)
        else:
            for wh in state["warehouses"]:
                if wh["id"] == dest_wh_id:
                    capacity = wh["capacity"]
                    break
            current_total_stock = sum(inv["stock_quantity"] for inv in state["inventory"] if inv["warehouse_id"] == dest_wh_id)

        # Check capacity
        if current_total_stock + qty <= capacity:
            capacity_validated.append(prop)
        else:
            # Scale down quantities to fit remaining space
            available_space = max(0, int(capacity - current_total_stock))
            if available_space > 0:
                prop["quantity"] = available_space
                capacity_validated.append(prop)
                logger.info(f"Scaled down proposal due to capacity boundaries. Store/WH ID {dest_store_id or dest_wh_id} remaining: {available_space}")

    reasoning = f"Capacity validations completed. Verified destination constraints; adjusted proposals to ensure zero capacity violations."
    return {
        "capacity_validated": capacity_validated,
        "reasoning": {"Capacity Agent": reasoning}
    }

# 6. Agent Node: Cost Agent
def cost_agent_node(state: AgentState) -> Dict[str, Any]:
    logger.info("Executing Cost Agent...")
    costed_proposals = []

    for prop in state["capacity_validated"]:
        # Find coordinates
        lat1, lon1 = 0.0, 0.0
        lat2, lon2 = 0.0, 0.0
        
        # Source coords
        src_store_id = prop["source_store_id"]
        src_wh_id = prop["source_warehouse_id"]
        if src_store_id is not None:
            for s in state["stores"]:
                if s["id"] == src_store_id:
                    lat1, lon1 = s["latitude"], s["longitude"]
                    break
        else:
            for w in state["warehouses"]:
                if w["id"] == src_wh_id:
                    lat1, lon1 = w["latitude"], w["longitude"]
                    break
                    
        # Destination coords
        dest_store_id = prop["destination_store_id"]
        dest_wh_id = prop["destination_warehouse_id"]
        if dest_store_id is not None:
            for s in state["stores"]:
                if s["id"] == dest_store_id:
                    lat2, lon2 = s["latitude"], s["longitude"]
                    break
        else:
            for w in state["warehouses"]:
                if w["id"] == dest_wh_id:
                    lat2, lon2 = w["latitude"], w["longitude"]
                    break

        distance = calculate_distance(lat1, lon1, lat2, lon2)
        
        # Fetch product properties (price, weight, holding cost)
        product = None
        for p in state["products"]:
            if p["id"] == prop["product_id"]:
                product = p
                break
                
        if product is None:
            continue
            
        qty = prop["quantity"]
        weight = product["weight"]
        price = product["price"]
        holding_cost = product["holding_cost"]
        
        # Cost math
        transfer_cost = distance * weight * qty * 0.15 # INR/USD per kg-km
        
        # Profit margin estimate (Price * 0.3 markup savings - shipping)
        expected_profit = (qty * price * 0.25) - transfer_cost
        
        # Holding Cost Saved calculation
        holding_cost_saved = holding_cost * qty * 4.5
        
        # Delivery speed improvement (assume truck travels at 60km/h, 10 hours daily)
        delivery_improvement = max(0.5, distance / 600.0) # speed bump in days
        
        costed = prop.copy()
        costed.update({
            "transfer_cost": round(transfer_cost, 2),
            "expected_profit": round(expected_profit, 2),
            "holding_cost_saved": round(holding_cost_saved, 2),
            "delivery_improvement": round(delivery_improvement, 1),
            "confidence_score": 0.94
        })
        costed_proposals.append(costed)

    reasoning = "Transfer and storage holding calculations finished. Estimated geodistance shipping expenses, expected markup profits, and delivery improvements."
    return {
        "costed_proposals": costed_proposals,
        "reasoning": {"Cost Agent": reasoning}
    }

# 7. Agent Node: Review Agent
def review_agent_node(state: AgentState) -> Dict[str, Any]:
    logger.info("Executing Review Agent...")
    final_recommendations = []
    
    for prop in state["costed_proposals"]:
        # Safety Check: Expected profit margin must be positive
        if prop["expected_profit"] <= 0:
            logger.info(f"Filtered proposal: negative expected margin ({prop['expected_profit']})")
            continue
            
        # Safety Check: Source store cannot transfer if it compromises its own safety stock
        src_store_id = prop["source_store_id"]
        prod_id = prop["product_id"]
        qty = prop["quantity"]
        
        if src_store_id is not None:
            source_inventory = None
            for inv in state["inventory"]:
                if inv["store_id"] == src_store_id and inv["product_id"] == prod_id:
                    source_inventory = inv
                    break
            
            if source_inventory:
                remaining_stock = source_inventory["stock_quantity"] - qty
                if remaining_stock < source_inventory["safety_stock"]:
                    logger.info(f"Filtered proposal: source Store {src_store_id} falls below safety stock buffer.")
                    continue
                    
        final_recommendations.append(prop)

    reasoning = f"Safety constraints reviewed. Discarded high-risk or low-margin transfers. Approved {len(final_recommendations)} network paths."
    return {
        "final_recommendations": final_recommendations,
        "reasoning": {"Review Agent": reasoning}
    }

# 8. Agent Node: Manager Agent
def manager_agent_node(state: AgentState) -> Dict[str, Any]:
    logger.info("Executing Manager Agent...")
    
    # Consolidate all reasoning logs
    reasoning_logs = state["reasoning"].copy()
    
    final_recs = []
    for rec in state["final_recommendations"]:
        source_name = ""
        if rec["source_store_id"] is not None:
            source_name = f"Store {rec['source_store_id']}"
        else:
            source_name = f"Warehouse {rec['source_warehouse_id']}"
            
        dest_name = ""
        if rec["destination_store_id"] is not None:
            dest_name = f"Store {rec['destination_store_id']}"
        else:
            dest_name = f"Warehouse {rec['destination_warehouse_id']}"
            
        reasoning_summary = {
            "demandAgent": reasoning_logs.get("Demand Agent"),
            "inventoryAgent": reasoning_logs.get("Inventory Agent"),
            "transferAgent": reasoning_logs.get("Transfer Agent"),
            "capacityAgent": reasoning_logs.get("Capacity Agent"),
            "costAgent": reasoning_logs.get("Cost Agent"),
            "reviewAgent": reasoning_logs.get("Review Agent")
        }
        
        rec_details = rec.copy()
        rec_details["business_reason"] = f"Move {rec['quantity']} units from {source_name} to {dest_name} to resolve SKU shortages and maximize service levels."
        rec_details["reasoning_json"] = json.dumps(reasoning_summary)
        final_recs.append(rec_details)
        
    reasoning = f"Optimization run consolidated. Finalized {len(final_recs)} recommended stock placements to distribute across fulfillment centers."
    return {
        "final_recommendations": final_recs,
        "reasoning": {"Manager Agent": reasoning}
    }

# Compile LangGraph Workflow
def build_multi_agent_graph():
    workflow = StateGraph(AgentState)
    
    # Add Nodes
    workflow.add_node("demand_agent", demand_agent_node)
    workflow.add_node("inventory_agent", inventory_agent_node)
    workflow.add_node("transfer_agent", transfer_agent_node)
    workflow.add_node("capacity_agent", capacity_agent_node)
    workflow.add_node("cost_agent", cost_agent_node)
    workflow.add_node("review_agent", review_agent_node)
    workflow.add_node("manager_agent", manager_agent_node)
    
    # Define Edges
    workflow.set_entry_point("demand_agent")
    workflow.add_edge("demand_agent", "inventory_agent")
    workflow.add_edge("inventory_agent", "transfer_agent")
    workflow.add_edge("transfer_agent", "capacity_agent")
    workflow.add_edge("capacity_agent", "cost_agent")
    workflow.add_edge("cost_agent", "review_agent")
    workflow.add_edge("review_agent", "manager_agent")
    workflow.add_edge("manager_agent", END)
    
    return workflow.compile()

# Instantiate compiled graph
agent_graph = build_multi_agent_graph()

# DB Helper: Fetch Optimization State Inputs
def load_state_from_db() -> Dict[str, Any]:
    engine = create_engine(DB_URL)
    state = {
        "inventory": [],
        "forecasts": [],
        "stores": [],
        "warehouses": [],
        "products": [],
        "demands": {},
        "shortages": [],
        "surpluses": [],
        "proposals": [],
        "capacity_validated": [],
        "costed_proposals": [],
        "final_recommendations": [],
        "reasoning": {}
    }
    
    with engine.connect() as conn:
        # Load Inventory
        rs = conn.execute(text("SELECT id, store_id, warehouse_id, product_id, stock_quantity, safety_stock FROM inventory"))
        state["inventory"] = [dict(row._mapping) for row in rs]
        
        # Load Forecasts
        rs = conn.execute(text("SELECT id, store_id, product_id, forecast_date, quantity, confidence_score FROM forecast"))
        state["forecasts"] = []
        for row in rs:
            r_dict = dict(row._mapping)
            # Serialize dates for compatibility
            if isinstance(r_dict["forecast_date"], datetime.date):
                # keep as date object in python state, main API will parse
                pass
            state["forecasts"].append(r_dict)
            
        # Load Stores
        rs = conn.execute(text("SELECT id, name, city, latitude, longitude, capacity FROM stores"))
        state["stores"] = [dict(row._mapping) for row in rs]
        
        # Load Warehouses
        rs = conn.execute(text("SELECT id, name, city, latitude, longitude, capacity FROM warehouses"))
        state["warehouses"] = [dict(row._mapping) for row in rs]
        
        # Load Products
        rs = conn.execute(text("SELECT id, sku, name, category, price, weight, holding_cost FROM products"))
        state["products"] = [dict(row._mapping) for row in rs]

    return state

# DB Helper: Save final recommendations to PostgreSQL
def save_recommendations_to_db(recommendations: List[Dict[str, Any]]):
    engine = create_engine(DB_URL)
    
    # 1. Clear previous PENDING recommendations to avoid overlapping options
    clear_query = "DELETE FROM recommendations WHERE status = 'PENDING'"
    
    insert_query = """
        INSERT INTO recommendations (
            source_store_id, source_warehouse_id, 
            destination_store_id, destination_warehouse_id, 
            product_id, quantity, transfer_cost, expected_profit, holding_cost_saved,
            delivery_improvement, confidence_score, status, 
            business_reason, reasoning, created_at, updated_at
        ) VALUES (
            :source_store_id, :source_warehouse_id, 
            :destination_store_id, :destination_warehouse_id, 
            :product_id, :quantity, :transfer_cost, :expected_profit, :holding_cost_saved,
            :delivery_improvement, :confidence_score, 'PENDING', 
            :business_reason, :reasoning_json, NOW(), NOW()
        )
    """
    
    with engine.begin() as conn:
        conn.execute(text(clear_query))
        for rec in recommendations:
            conn.execute(text(insert_query), rec)
            
    logger.info(f"Persisted {len(recommendations)} pending recommendations to PostgreSQL database.")
