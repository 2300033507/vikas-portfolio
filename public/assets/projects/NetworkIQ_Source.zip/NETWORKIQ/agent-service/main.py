import os
import logging
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import datetime
from agents import agent_graph, load_state_from_db, save_recommendations_to_db

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("Agent-Service-API")

app = FastAPI(
    title="NetworkIQ - Multi-Agent Optimization Service",
    description="Python microservice powered by FastAPI and LangGraph executing cooperative supply chain inventory allocations.",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health_check():
    db_connected = False
    try:
        load_state_from_db()
        db_connected = True
    except Exception as e:
        logger.error(f"Health check failed to query database: {e}")
        
    return {
        "status": "healthy" if db_connected else "database_unreachable",
        "database_connected": db_connected,
        "timestamp": datetime.datetime.now()
    }

@app.post("/optimize", summary="Trigger cooperative Multi-Agent optimization")
def run_optimization():
    """
    Retrieves full warehouse, store, inventory, and forecasted SKU quantities.
    Initializes LangGraph state, coordinates agent reviews, and inserts recommended transfers into PostgreSQL.
    """
    logger.info("Manual multi-agent optimization trigger request received.")
    
    # 1. Fetch current network statistics from database
    try:
        initial_state = load_state_from_db()
    except Exception as e:
        logger.error(f"Failed to load inventory network state from database: {e}")
        raise HTTPException(status_code=503, detail=f"Database state load failure: {str(e)}")

    if not initial_state["inventory"]:
        raise HTTPException(status_code=400, detail="Database contains no inventory records. Ingestion is required first.")

    # 2. Compile and execute LangGraph agents cycle
    try:
        logger.info("Executing LangGraph multi-agent collaborative cycle...")
        result_state = agent_graph.invoke(initial_state)
    except Exception as e:
        logger.error(f"LangGraph execution halted with error: {e}")
        raise HTTPException(status_code=500, detail=f"Multi-agent graph execution error: {str(e)}")

    # 3. Extract recommendations and persist in DB
    recommendations = result_state.get("final_recommendations", [])
    try:
        save_recommendations_to_db(recommendations)
    except Exception as e:
        logger.error(f"Failed to persist optimized recommendations: {e}")
        raise HTTPException(status_code=500, detail=f"Database write-back failure: {str(e)}")

    # 4. Return report
    agent_reasoning = result_state.get("reasoning", {})
    return {
        "status": "success",
        "timestamp": datetime.datetime.now().isoformat(),
        "recommendations_generated": len(recommendations),
        "agent_contributions": {
            "Demand Agent": agent_reasoning.get("Demand Agent", "Skipped"),
            "Inventory Agent": agent_reasoning.get("Inventory Agent", "Skipped"),
            "Transfer Agent": agent_reasoning.get("Transfer Agent", "Skipped"),
            "Capacity Agent": agent_reasoning.get("Capacity Agent", "Skipped"),
            "Cost Agent": agent_reasoning.get("Cost Agent", "Skipped"),
            "Review Agent": agent_reasoning.get("Review Agent", "Skipped"),
            "Manager Agent": agent_reasoning.get("Manager Agent", "Skipped")
        }
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
