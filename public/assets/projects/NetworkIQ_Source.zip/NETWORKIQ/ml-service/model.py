import os
import pickle
import logging
import datetime
import numpy as np
import pandas as pd
from sqlalchemy import create_engine, text
from xgboost import XGBRegressor
from sklearn.linear_model import LinearRegression

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ML-Forecaster")

# DB Configuration
DB_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/networkiq")
MODEL_DIR = "models"

# Ensure models directory exists
if not os.path.exists(MODEL_DIR):
    os.makedirs(MODEL_DIR)

class DemandForecastModel:

    def __init__(self):
        self.engine = None
        try:
            self.engine = create_engine(DB_URL)
            logger.info("Database engine configured successfully.")
        except Exception as e:
            logger.error(f"Failed to connect to database at startup: {e}")

    def fetch_sales_data(self) -> pd.DataFrame:
        """Fetch historical sales data from database."""
        if not self.engine:
            raise ConnectionError("Database engine is not initialized.")
        
        query = """
            SELECT store_id, product_id, sale_date, quantity, revenue 
            FROM sales
            ORDER BY sale_date ASC
        """
        with self.engine.connect() as conn:
            df = pd.read_sql(text(query), conn)
        logger.info(f"Fetched {len(df)} sales records from database.")
        return df

    def train_and_forecast_sku(self, store_id: int, product_id: int, df_sales: pd.DataFrame, future_days: int = 7) -> list:
        """Trains a model for a specific SKU and Store, and predicts demand for the next future_days."""
        df_sku = df_sales[(df_sales['store_id'] == store_id) & (df_sales['product_id'] == product_id)].copy()
        
        # Determine prediction dates (next 7 days starting tomorrow)
        today = datetime.date.today()
        prediction_dates = [today + datetime.timedelta(days=i) for i in range(1, future_days + 1)]
        
        # Fallback if insufficient historical data points
        if len(df_sku) < 5:
            logger.debug(f"Insufficient sales data ({len(df_sku)} records) for Store {store_id}, Product {product_id}. Using statistical moving average fallback.")
            avg_qty = df_sku['quantity'].mean() if not df_sku.empty else 15.0
            # Simple fallback trend: slightly higher demand on weekends
            predictions = []
            for date in prediction_dates:
                weekday = date.weekday()
                multiplier = 1.2 if weekday >= 5 else 1.0  # weekend bump
                pred_val = int(round(avg_qty * multiplier))
                predictions.append({
                    "store_id": store_id,
                    "product_id": product_id,
                    "forecast_date": date,
                    "quantity": max(1, pred_val),
                    "confidence_score": 0.70
                })
            return predictions

        # Feature Engineering: Extract date attributes
        df_sku['sale_date'] = pd.to_datetime(df_sku['sale_date'])
        df_sku['year'] = df_sku['sale_date'].dt.year
        df_sku['month'] = df_sku['sale_date'].dt.month
        df_sku['day'] = df_sku['sale_date'].dt.day
        df_sku['dayofweek'] = df_sku['sale_date'].dt.dayofweek
        df_sku['dayofyear'] = df_sku['sale_date'].dt.dayofyear

        X = df_sku[['year', 'month', 'day', 'dayofweek', 'dayofyear']].values
        y = df_sku['quantity'].values

        # Select model based on sample size: XGBoost for >=10, LinearRegression for 5-9
        if len(df_sku) >= 10:
            model = XGBRegressor(n_estimators=50, max_depth=3, learning_rate=0.1, objective='reg:squarederror')
            model_type = "XGBoost"
        else:
            model = LinearRegression()
            model_type = "LinearRegression"

        model.fit(X, y)
        logger.info(f"Trained {model_type} model for Store {store_id}, SKU {product_id} (samples: {len(df_sku)}).")

        # Save model file
        model_path = os.path.join(MODEL_DIR, f"model_s{store_id}_p{product_id}.pkl")
        with open(model_path, 'wb') as f:
            pickle.dump(model, f)

        # Prepare future dates X matrix
        future_X = []
        for date in prediction_dates:
            future_X.append([
                date.year,
                date.month,
                date.day,
                date.weekday(),
                date.timetuple().tm_yday
            ])
        future_X = np.array(future_X)

        # Generate forecasts
        y_pred = model.predict(future_X)
        
        predictions = []
        for i, date in enumerate(prediction_dates):
            predicted_qty = int(round(max(1.0, float(y_pred[i]))))
            predictions.append({
                "store_id": store_id,
                "product_id": product_id,
                "forecast_date": date,
                "quantity": predicted_qty,
                "confidence_score": 0.85 if model_type == "XGBoost" else 0.78
            })
            
        return predictions

    def execute_forecasting(self) -> dict:
        """Triggers training and saves predictions for all SKUs and locations to the DB."""
        if not self.engine:
            raise ConnectionError("PostgreSQL database connection is unavailable.")

        try:
            df_sales = self.fetch_sales_data()
        except Exception as e:
            logger.error(f"Failed to fetch sales history: {e}")
            return {"status": "error", "message": f"Failed to fetch sales history: {e}"}

        # Query all active store-product combinations from inventory
        query_inventory = "SELECT DISTINCT store_id, product_id FROM inventory WHERE store_id IS NOT NULL"
        with self.engine.connect() as conn:
            df_inventory = pd.read_sql(text(query_inventory), conn)

        if df_inventory.empty:
            logger.warning("No store inventory records found. Seeding forecast directly fails.")
            return {"status": "warning", "message": "No inventory records available to forecast."}

        all_predictions = []
        for _, row in df_inventory.iterrows():
            store_id = int(row['store_id'])
            product_id = int(row['product_id'])
            
            try:
                preds = self.train_and_forecast_sku(store_id, product_id, df_sales)
                all_predictions.extend(preds)
            except Exception as e:
                logger.error(f"Error forecasting for Store {store_id}, SKU {product_id}: {e}")

        # Bulk save/update in database
        if all_predictions:
            self.save_predictions_to_db(all_predictions)
            return {
                "status": "success",
                "total_records": len(all_predictions),
                "message": f"Successfully updated forecast records for {len(df_inventory)} store-SKU pairings."
            }
        
        return {"status": "warning", "message": "No predictions generated."}

    def save_predictions_to_db(self, predictions: list):
        """Insert or update predictions in PostgreSQL 'forecast' table."""
        upsert_query = """
            INSERT INTO forecast (store_id, product_id, forecast_date, quantity, confidence_score, created_at)
            VALUES (:store_id, :product_id, :forecast_date, :quantity, :confidence_score, NOW())
            ON CONFLICT (store_id, product_id, forecast_date)
            DO UPDATE SET 
                quantity = EXCLUDED.quantity,
                confidence_score = EXCLUDED.confidence_score;
        """
        
        with self.engine.begin() as conn:
            for pred in predictions:
                conn.execute(text(upsert_query), pred)
        logger.info(f"Persisted {len(predictions)} forecasts to forecast table.")
