import os
import logging
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import datetime
from model import DemandForecastModel

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ML-Service")

app = FastAPI(
    title="NetworkIQ - Machine Learning Forecasting Service",
    description="Python microservice powered by FastAPI, Pandas, Scikit-learn, and XGBoost for SKU demand forecasting.",
    version="1.0.0"
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Instantiate the forecasting engine
forecaster = DemandForecastModel()

class PredictionResponse(BaseModel):
    store_id: int
    product_id: int
    forecast_date: datetime.date
    quantity: int
    confidence_score: float

@app.get("/health")
def health_check():
    """Service status health check."""
    status = "healthy"
    db_connected = False
    if forecaster.engine:
        try:
            with forecaster.engine.connect() as conn:
                db_connected = True
        except Exception:
            status = "database_unreachable"
            
    return {
        "status": status,
        "database_connected": db_connected,
        "timestamp": datetime.datetime.now()
    }

@app.post("/predict", summary="Train models and generate future demand forecasts")
def trigger_predictions():
    """
    Triggers model training for all stores and product SKU combinations.
    Updates the 'forecast' database table with the predictions.
    """
    logger.info("Received manual forecast generation trigger request.")
    if not forecaster.engine:
        raise HTTPException(status_code=503, detail="PostgreSQL database connection is offline.")
    
    result = forecaster.execute_forecasting()
    if result.get("status") == "error":
        raise HTTPException(status_code=500, detail=result.get("message"))
        
    return result

@app.get("/predict/store/{store_id}/product/{product_id}", 
         response_model=list[PredictionResponse],
         summary="Predict SKU demand for a specific location")
def predict_sku_demand(store_id: int, product_id: int):
    """
    Retrieves or generates forecasts for a specific store and product.
    Loads the trained model file from disk automatically. If no model is found,
    it attempts training first, falling back to a moving average heuristic if data is unavailable.
    """
    logger.info(f"Fetch request for Store {store_id}, Product {product_id}")
    
    # 1. Fetch sales data to feed the model pipeline
    sales_df = None
    if forecaster.engine:
        try:
            sales_df = forecaster.fetch_sales_data()
        except Exception as e:
            logger.warn(f"Failed to query database sales table ({e}). Using mock/heuristic forecast inputs.")

    # 2. Run prediction pipeline
    try:
        predictions = forecaster.train_and_forecast_sku(store_id, product_id, sales_df if sales_df is not None else None)
        return predictions
    except Exception as e:
        logger.error(f"Prediction execution failed: {e}")
        raise HTTPException(status_code=500, detail=f"Prediction pipeline failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    # Read environment port or default to 5000
    port = int(os.getenv("PORT", 5000))
    uvicorn.run(app, host="0.0.0.0", port=port)
