import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Inventory from './pages/Inventory';
import UploadCsv from './pages/UploadCsv';
import Forecast from './pages/Forecast';
import Recommendations from './pages/Recommendations';
import Reports from './pages/Reports';
import Settings from './pages/Settings';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem('token');
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

// Layout Wrapper
const DashboardLayout = () => {
  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 flex">
      {/* Sidebar navigation */}
      <Sidebar />
      
      {/* Main content body */}
      <div className="flex-1 pl-64 flex flex-col min-h-screen">
        {/* Top Header bar */}
        <Header />
        
        {/* Main views canvas */}
        <main className="flex-1 mt-16 p-8 overflow-y-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/inventory" element={<Inventory />} />
            <Route path="/upload" element={<UploadCsv />} />
            <Route path="/forecast" element={<Forecast />} />
            <Route path="/recommendations" element={<Recommendations />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

function App() {
  return (
    <Router>
      <Routes>
        {/* Unprotected Login route */}
        <Route path="/login" element={<Login />} />
        
        {/* Protected Dashboard Layout wrapper */}
        <Route 
          path="/*" 
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;
