import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Boxes, 
  UploadCloud, 
  LineChart, 
  GitPullRequest, 
  FileText, 
  Settings as SettingsIcon, 
  LogOut,
  BrainCircuit
} from 'lucide-react';
import { logOutUser } from '../api';

const Sidebar = () => {
  const username = localStorage.getItem('username') || 'User';
  const role = localStorage.getItem('role') || 'ROLE_PLANNER';
  const friendlyRole = role.replace('ROLE_', '');

  const menuItems = [
    { name: 'Dashboard', path: '/', icon: <LayoutDashboard size={20} /> },
    { name: 'Inventory', path: '/inventory', icon: <Boxes size={20} /> },
    { name: 'Upload CSV', path: '/upload', icon: <UploadCloud size={20} /> },
    { name: 'Forecast', path: '/forecast', icon: <LineChart size={20} /> },
    { name: 'Recommendations', path: '/recommendations', icon: <GitPullRequest size={20} /> },
    { name: 'Reports', path: '/reports', icon: <FileText size={20} /> },
    { name: 'Settings', path: '/settings', icon: <SettingsIcon size={20} /> },
  ];

  return (
    <aside className="w-64 h-screen fixed left-0 top-0 glass-panel flex flex-col border-r border-slate-800/80 z-20">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-800/80 flex items-center space-x-3">
        <div className="p-2 bg-indigo-600/35 rounded-lg border border-indigo-500/50 shadow-[0_0_10px_rgba(99,102,241,0.3)]">
          <BrainCircuit className="text-indigo-400 animate-pulse" size={24} />
        </div>
        <div>
          <h1 className="font-display font-bold text-lg leading-tight tracking-wider bg-gradient-to-r from-indigo-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent uppercase">
            NetworkIQ
          </h1>
          <span className="text-[10px] text-slate-500 tracking-widest font-medium uppercase">
            Optimization Engine
          </span>
        </div>
      </div>

      {/* Nav Links */}
      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        {menuItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) => `
              flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium text-sm
              ${isActive 
                ? 'bg-gradient-to-r from-indigo-600/20 to-purple-600/20 text-indigo-300 border-l-4 border-indigo-500 glow-border-indigo shadow-[0_0_15px_rgba(99,102,241,0.05)]' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'}
            `}
          >
            {item.icon}
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>

      {/* User Section & Logout */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
        <div className="flex items-center justify-between p-2 rounded-lg mb-2">
          <div className="truncate pr-2">
            <p className="text-sm font-semibold text-slate-200 truncate">{username}</p>
            <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider mt-0.5">
              {friendlyRole}
            </p>
          </div>
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
        </div>
        <button
          onClick={logOutUser}
          className="w-full flex items-center justify-center space-x-2 py-2.5 rounded-lg border border-slate-800 hover:bg-red-500/10 hover:border-red-500/40 hover:text-red-400 text-slate-400 text-xs font-semibold tracking-wide transition-all duration-200"
        >
          <LogOut size={14} />
          <span>Logout Session</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
