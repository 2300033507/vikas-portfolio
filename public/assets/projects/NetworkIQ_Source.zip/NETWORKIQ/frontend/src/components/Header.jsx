import React from 'react';
import { useLocation } from 'react-router-dom';
import { ShieldCheck, Activity, Bell } from 'lucide-react';

const Header = () => {
  const location = useLocation();
  const role = localStorage.getItem('role') || 'ROLE_PLANNER';
  const friendlyRole = role.replace('ROLE_', '');

  const getPageTitle = (path) => {
    switch (path) {
      case '/': return 'Optimization Dashboard';
      case '/inventory': return 'Inventory Placement';
      case '/upload': return 'CSV Data Ingestion';
      case '/forecast': return 'Demand Forecaster';
      case '/recommendations': return 'AI Recommendation Panel';
      case '/reports': return 'Reports & Audits';
      case '/settings': return 'System Settings';
      default: return 'NetworkIQ Platform';
    }
  };

  return (
    <header className="h-16 fixed top-0 right-0 left-64 backdrop-blur-md bg-slate-950/40 border-b border-slate-800/60 flex items-center justify-between px-8 z-10">
      {/* Title */}
      <div>
        <h2 className="text-xl font-display font-bold text-slate-100 tracking-wide">
          {getPageTitle(location.pathname)}
        </h2>
      </div>

      {/* Info Indicators */}
      <div className="flex items-center space-x-6">
        {/* Status Badge */}
        <div className="flex items-center space-x-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 rounded-full text-[11px] font-semibold text-emerald-400">
          <Activity size={12} className="animate-pulse" />
          <span>System Active</span>
        </div>

        {/* Security Role Badge */}
        <div className="flex items-center space-x-1.5 px-3 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-full text-[11px] font-semibold text-indigo-400">
          <ShieldCheck size={12} />
          <span>Auth: {friendlyRole}</span>
        </div>

        {/* Notification Icon */}
        <button className="p-2 hover:bg-slate-800/50 rounded-lg text-slate-400 hover:text-slate-200 transition-all duration-150 relative">
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-indigo-500 ring-2 ring-slate-900"></span>
        </button>
      </div>
    </header>
  );
};

export default Header;
