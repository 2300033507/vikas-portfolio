import React from 'react';
import { 
  User, 
  Mail, 
  Shield, 
  Database, 
  HelpCircle, 
  Settings as SettingsIcon,
  Server
} from 'lucide-react';

const Settings = () => {
  const username = localStorage.getItem('username') || 'Planner';
  const email = localStorage.getItem('email') || 'planner@networkiq.com';
  const role = localStorage.getItem('role') || 'ROLE_PLANNER';
  const friendlyRole = role.replace('ROLE_', '');

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-10">
      {/* Profile Section */}
      <div className="glass-panel p-6 rounded-2xl space-y-4">
        <h3 className="text-sm font-semibold text-slate-300 flex items-center space-x-2">
          <User size={16} className="text-indigo-400" />
          <span>User Profile</span>
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
          <div className="flex items-center space-x-3 p-4 bg-slate-950/40 rounded-xl border border-slate-800/40">
            <User size={18} className="text-slate-500" />
            <div>
              <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block">Username</span>
              <span className="text-xs font-semibold text-slate-200 block mt-0.5">{username}</span>
            </div>
          </div>

          <div className="flex items-center space-x-3 p-4 bg-slate-950/40 rounded-xl border border-slate-800/40">
            <Mail size={18} className="text-slate-500" />
            <div>
              <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block">Email Address</span>
              <span className="text-xs font-semibold text-slate-200 block mt-0.5">{email}</span>
            </div>
          </div>

          <div className="flex items-center space-x-3 p-4 bg-slate-950/40 rounded-xl border border-slate-800/40 border-l-4 border-l-indigo-500">
            <Shield size={18} className="text-indigo-400" />
            <div>
              <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block">Granted Authority</span>
              <span className="text-xs font-bold text-indigo-400 block mt-0.5">{friendlyRole}</span>
            </div>
          </div>
        </div>
      </div>

      {/* System Configurations */}
      <div className="glass-panel p-6 rounded-2xl space-y-4">
        <h3 className="text-sm font-semibold text-slate-300 flex items-center space-x-2">
          <Server size={16} className="text-cyan-400" />
          <span>Optimization Service Parameters</span>
        </h3>

        <div className="space-y-4 divide-y divide-slate-800/40 text-xs">
          <div className="flex items-center justify-between py-3">
            <div>
              <span className="font-semibold text-slate-200 block">Spring Boot API Gateway</span>
              <span className="text-[10px] text-slate-500 mt-0.5 block">Standard core services Orchestrator connection endpoint.</span>
            </div>
            <span className="font-mono text-[10px] px-2.5 py-1 bg-slate-950 text-slate-400 rounded-lg border border-slate-850">
              http://localhost:8080
            </span>
          </div>

          <div className="flex items-center justify-between py-3">
            <div>
              <span className="font-semibold text-slate-200 block">FastAPI XGBoost Forecast Microservice</span>
              <span className="text-[10px] text-slate-500 mt-0.5 block">XGBoost prediction engine REST endpoint.</span>
            </div>
            <span className="font-mono text-[10px] px-2.5 py-1 bg-slate-950 text-slate-400 rounded-lg border border-slate-850">
              http://localhost:5000
            </span>
          </div>

          <div className="flex items-center justify-between py-3">
            <div>
              <span className="font-semibold text-slate-200 block">FastAPI LangGraph Cooperating Agent Service</span>
              <span className="text-[10px] text-slate-500 mt-0.5 block">Multi-agent LangGraph workflow execution endpoints.</span>
            </div>
            <span className="font-mono text-[10px] px-2.5 py-1 bg-slate-950 text-slate-400 rounded-lg border border-slate-850">
              http://localhost:8000
            </span>
          </div>

          <div className="flex items-center justify-between py-3">
            <div>
              <span className="font-semibold text-slate-200 block">Safety Stock Threshold multiplier</span>
              <span className="text-[10px] text-slate-500 mt-0.5 block">Baseline safety margin buffer added above forecasts.</span>
            </div>
            <span className="font-bold text-indigo-400 font-mono">1.25x Buffer</span>
          </div>
        </div>
      </div>

      {/* Database status */}
      <div className="glass-panel p-6 rounded-2xl flex items-center justify-between border-l-4 border-l-emerald-500">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-emerald-500/10 rounded-xl text-emerald-400">
            <Database size={18} />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-slate-200">PostgreSQL Relational DB Connected</h4>
            <p className="text-[10px] text-slate-500 mt-0.5">Storing user credentials, physical inventory, sales history, and forecasts.</p>
          </div>
        </div>
        <div className="h-2 w-2 rounded-full bg-emerald-500 glow-border-indigo"></div>
      </div>
    </div>
  );
};

export default Settings;
