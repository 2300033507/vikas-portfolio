import React, { useState } from 'react';
import { 
  UploadCloud, 
  ShieldAlert, 
  FileSpreadsheet, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import api from '../api';

const UploadCsv = () => {
  const [file, setFile] = useState(null);
  const [dragActive, setDragActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState(null);
  const [error, setError] = useState('');

  const userRole = localStorage.getItem('role') || 'ROLE_PLANNER';
  const isAdmin = userRole === 'ROLE_ADMIN';

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.name.endsWith('.csv') || droppedFile.name.endsWith('.txt')) {
        setFile(droppedFile);
        setError('');
      } else {
        setError('Unsupported format. Please drop a valid CSV file.');
      }
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (selectedFile.name.endsWith('.csv') || selectedFile.name.endsWith('.txt')) {
        setFile(selectedFile);
        setError('');
      } else {
        setError('Unsupported format. Please select a valid CSV file.');
      }
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;

    setLoading(true);
    setError('');
    setReport(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await api.post('/api/csv/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setReport(response.data);
      setFile(null);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || 'CSV Ingestion failed. Verify file boundaries and formatting.');
    } finally {
      setLoading(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="glass-panel p-8 rounded-2xl border-l-4 border-l-yellow-500 max-w-2xl mx-auto mt-10">
        <div className="flex space-x-4">
          <ShieldAlert className="text-yellow-500 flex-shrink-0" size={36} />
          <div>
            <h3 className="text-base font-display font-bold text-slate-200">Ingestion Access Restricted</h3>
            <p className="text-sm text-slate-400 mt-2 leading-relaxed">
              Only users with Administrator credentials (`ROLE_ADMIN`) are authorized to upload and seed Indian Store datasets. 
              Planners are authorized to run multi-agent optimizations, review generated recommendations, and approve transfers.
            </p>
            <div className="mt-4 p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-slate-500">
              Tip: Log out and sign in using the <b>System Admin</b> quick-fill credentials to test this module.
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-10">
      {/* Upload Box */}
      <div className="glass-panel p-8 rounded-2xl">
        <h3 className="text-sm font-semibold text-slate-300 mb-4">Ingest Network Dataset</h3>
        <p className="text-xs text-slate-400 mb-6">
          Upload Indian Store data. The spreadsheet must match the standard 13-column schema (Store details, Product SKU descriptors, and physical stock volumes).
        </p>

        <form onSubmit={handleUpload} className="space-y-6">
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center transition-all ${
              dragActive 
                ? 'border-indigo-500 bg-indigo-550/5' 
                : file 
                  ? 'border-emerald-500/50 bg-emerald-550/5' 
                  : 'border-slate-800 hover:border-slate-700 hover:bg-slate-900/10'
            }`}
          >
            {file ? (
              <FileSpreadsheet className="text-emerald-400 animate-bounce mb-4" size={48} />
            ) : (
              <UploadCloud className="text-slate-500 mb-4" size={48} />
            )}

            <p className="text-xs font-semibold text-slate-300 text-center">
              {file ? file.name : "Drag & Drop CSV file here"}
            </p>
            <p className="text-[10px] text-slate-500 mt-1 text-center">
              {file ? `${(file.size / 1024).toFixed(1)} KB` : "Supports .csv or .txt spreadsheets up to 10MB"}
            </p>

            <label className="mt-4 px-4 py-2 bg-slate-800 hover:bg-slate-700/80 text-slate-300 hover:text-slate-100 rounded-xl text-xs font-semibold border border-slate-700 cursor-pointer transition-all active:scale-[0.98]">
              Browse Files
              <input type="file" onChange={handleFileChange} accept=".csv,.txt" className="hidden" />
            </label>
          </div>

          {error && (
            <div className="flex items-start space-x-2.5 p-3.5 bg-red-500/10 border border-red-500/30 rounded-xl text-xs text-red-400">
              <XCircle size={16} className="flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={!file || loading}
            className="w-full flex items-center justify-center space-x-2 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-slate-100 font-bold rounded-xl text-xs transition-all active:scale-[0.98] shadow-lg shadow-indigo-600/15"
          >
            {loading ? (
              <>
                <RefreshCw size={14} className="animate-spin" />
                <span>Processing Spreadsheet Lines...</span>
              </>
            ) : (
              <span>Begin Ingestion</span>
            )}
          </button>
        </form>
      </div>

      {/* Summary Report */}
      {report && (
        <div className="glass-panel p-8 rounded-2xl space-y-6">
          <div className="flex items-center space-x-3 border-b border-slate-800/80 pb-4">
            <CheckCircle2 className="text-emerald-400" size={24} />
            <h3 className="text-base font-display font-bold text-slate-200">CSV Process Summary</h3>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-6">
            <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/40">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Total Rows</p>
              <h2 className="text-3xl font-display font-black text-slate-100 mt-1">{report.totalRecords}</h2>
            </div>
            <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/40 border-l-4 border-l-emerald-500">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider text-emerald-400">Imported</p>
              <h2 className="text-3xl font-display font-black text-emerald-400 mt-1">{report.imported}</h2>
            </div>
            <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/40 border-l-4 border-l-red-500">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider text-red-400">Failed</p>
              <h2 className="text-3xl font-display font-black text-red-400 mt-1">{report.failed}</h2>
            </div>
          </div>

          {/* Errors log */}
          {report.errors && report.errors.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-xs font-semibold text-slate-300">
                <AlertTriangle className="text-yellow-500" size={14} />
                <span>Parser Discrepancies and Warnings ({report.errors.length})</span>
              </div>
              <div className="max-h-60 overflow-y-auto bg-slate-950 border border-slate-850 rounded-xl p-4 font-mono text-[10px] text-slate-400 space-y-2">
                {report.errors.map((err, i) => (
                  <div key={i} className="py-1 border-b border-slate-900/60 last:border-0">
                    <span className="text-red-500">⚠</span> {err}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default UploadCsv;
