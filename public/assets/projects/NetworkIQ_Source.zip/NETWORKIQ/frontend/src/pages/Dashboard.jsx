import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Warehouse, 
  Tag, 
  Coins, 
  TrendingUp, 
  AlertTriangle, 
  Sparkles,
  RefreshCw,
  GitPullRequest
} from 'lucide-react';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend, 
  ArcElement 
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import api from '../api';

ChartJS.register(
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend, 
  ArcElement
);

const Dashboard = () => {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const fetchMetrics = async (showGlow = false) => {
    if (showGlow) setRefreshing(true);
    try {
      const response = await api.get('/api/dashboard/metrics');
      setMetrics(response.data);
    } catch (err) {
      console.error(err);
      setError('Failed to fetch dashboard metrics.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="flex flex-col items-center space-y-4">
          <RefreshCw className="text-indigo-500 animate-spin" size={40} />
          <p className="text-slate-400 text-sm">Assembling network inventory state...</p>
        </div>
      </div>
    );
  }

  // Chart 1: Shortages vs Excess Stock
  const barChartData = {
    labels: ['Current Stock', 'Forecasted Sales', 'Safety Stock Level', 'Net Shortages', 'Net Surplus'],
    datasets: [
      {
        label: 'Quantity (Units)',
        data: metrics ? [
          metrics.totalCurrentStock,
          metrics.totalForecastedDemand || 1500, // Fallback placeholder if ML not run
          metrics.totalCurrentStock - metrics.totalExcessStock + metrics.totalShortages, // Total safety target
          metrics.totalShortages,
          metrics.totalExcessStock
        ] : [0, 0, 0, 0, 0],
        backgroundColor: [
          'rgba(99, 102, 241, 0.65)',  // Indigo
          'rgba(34, 211, 238, 0.65)',   // Cyan
          'rgba(168, 85, 247, 0.65)',   // Purple
          'rgba(239, 68, 68, 0.65)',    // Red
          'rgba(16, 185, 129, 0.65)'    // Emerald
        ],
        borderColor: [
          '#6366f1', '#22d3ee', '#a855f7', '#ef4444', '#10b981'
        ],
        borderWidth: 1.5,
        borderRadius: 8
      }
    ]
  };

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#0f172a',
        titleFont: { family: 'Outfit' },
        bodyFont: { family: 'Inter' },
        borderColor: '#1e293b',
        borderWidth: 1
      }
    },
    scales: {
      x: {
        grid: { color: 'rgba(51, 65, 85, 0.2)' },
        ticks: { color: '#94a3b8', font: { family: 'Inter', size: 10 } }
      },
      y: {
        grid: { color: 'rgba(51, 65, 85, 0.2)' },
        ticks: { color: '#94a3b8', font: { family: 'Inter' } }
      }
    }
  };

  // Chart 2: Inventory Value Distribution
  const doughnutData = {
    labels: ['In-Stock Value', 'Shortage Deficit Cost', 'Idle Excess Capital'],
    datasets: [
      {
        data: metrics ? [
          metrics.totalInventoryValue,
          metrics.totalShortages * 15000, // estimated cost per SKU deficit
          metrics.totalExcessStock * 12000  // estimated idle cost
        ] : [0, 0, 0],
        backgroundColor: [
          'rgba(99, 102, 241, 0.75)',
          'rgba(239, 68, 68, 0.75)',
          'rgba(234, 179, 8, 0.75)'
        ],
        borderColor: ['#6366f1', '#ef4444', '#eab308'],
        borderWidth: 1.5
      }
    ]
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right',
        labels: {
          color: '#cbd5e1',
          font: { family: 'Inter', size: 11 },
          padding: 15
        }
      },
      tooltip: {
        backgroundColor: '#0f172a',
        borderColor: '#1e293b',
        borderWidth: 1
      }
    }
  };

  return (
    <div className="space-y-8 pb-10">
      {/* Top Banner */}
      <div className="flex justify-between items-center bg-slate-900/40 p-4 border border-slate-800/50 rounded-2xl">
        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <Sparkles className="text-indigo-400 animate-spin" size={14} />
          <span>LangGraph Cooperating multi-agent pipeline ready for transfers run.</span>
        </div>
        <button
          onClick={() => fetchMetrics(true)}
          disabled={refreshing}
          className="flex items-center space-x-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700/80 text-slate-200 hover:text-slate-100 rounded-lg text-xs font-semibold border border-slate-700 transition-all active:scale-[0.97]"
        >
          <RefreshCw size={12} className={refreshing ? 'animate-spin' : ''} />
          <span>{refreshing ? 'Syncing...' : 'Sync Metrics'}</span>
        </button>
      </div>

      {/* Grid KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Stores count */}
        <div className="glass-panel p-6 rounded-2xl flex items-center space-x-4">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
            <Building2 size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Retail Stores</p>
            <h3 className="text-2xl font-display font-bold mt-1 text-slate-100">{metrics.totalStores}</h3>
          </div>
        </div>

        {/* Warehouses count */}
        <div className="glass-panel p-6 rounded-2xl flex items-center space-x-4">
          <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl text-purple-400">
            <Warehouse size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Warehouses</p>
            <h3 className="text-2xl font-display font-bold mt-1 text-slate-100">{metrics.totalWarehouses}</h3>
          </div>
        </div>

        {/* Active SKUs */}
        <div className="glass-panel p-6 rounded-2xl flex items-center space-x-4">
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-cyan-400">
            <Tag size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Catalog SKUs</p>
            <h3 className="text-2xl font-display font-bold mt-1 text-slate-100">{metrics.totalSkus}</h3>
          </div>
        </div>

        {/* Inventory Value */}
        <div className="glass-panel p-6 rounded-2xl flex items-center space-x-4">
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
            <Coins size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Inventory Capital</p>
            <h3 className="text-2xl font-display font-bold mt-1 text-emerald-400">
              ₹{metrics.totalInventoryValue.toLocaleString('en-IN')}
            </h3>
          </div>
        </div>
      </div>

      {/* Alert Gauges */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Service Level Gauge */}
        <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between">
          <div>
            <h4 className="text-sm font-semibold text-slate-300 mb-2">Network Service Level</h4>
            <p className="text-xs text-slate-400">Target fill rate ratio of products meeting safety stock criteria.</p>
          </div>
          <div className="my-6 flex flex-col items-center">
            <div className="relative flex items-center justify-center">
              {/* Circular progress display */}
              <svg className="w-36 h-36 transform -rotate-90">
                <circle cx="72" cy="72" r="62" strokeWidth="8" stroke="#1f2937" fill="transparent" />
                <circle cx="72" cy="72" r="62" strokeWidth="8" stroke="url(#indigoGrad)" fill="transparent" 
                        strokeDasharray={2 * Math.PI * 62} 
                        strokeDashoffset={2 * Math.PI * 62 * (1 - metrics.serviceLevel / 100)} />
                <defs>
                  <linearGradient id="indigoGrad" x1="1" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#818cf8" />
                    <stop offset="100%" stopColor="#4f46e5" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-3xl font-display font-black text-slate-100">{metrics.serviceLevel}%</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest">Calculated</span>
              </div>
            </div>
          </div>
          <div className="text-center text-xs text-slate-400 bg-slate-950/40 py-2 rounded-xl border border-slate-800/40">
            {metrics.serviceLevel >= 90 ? 'Healthy service fills across warehouses.' : 'Attention required: Stockout threats detected.'}
          </div>
        </div>

        {/* Shortages panel */}
        <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between border-l-4 border-l-red-500">
          <div className="flex justify-between items-start">
            <div>
              <h4 className="text-sm font-semibold text-slate-300">Out-Of-Stock Threats</h4>
              <p className="text-xs text-slate-400 mt-1">Total units missing to meet safety buffers.</p>
            </div>
            <div className="p-2 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400">
              <AlertTriangle size={18} />
            </div>
          </div>
          <div className="my-4">
            <h2 className="text-5xl font-display font-black text-red-500">{metrics.totalShortages}</h2>
            <span className="text-xs text-slate-400">Units required immediately</span>
          </div>
          <div className="space-y-2">
            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-red-500" style={{ width: `${Math.min(100, (metrics.totalShortages / (metrics.totalCurrentStock || 1)) * 100)}%` }}></div>
            </div>
            <p className="text-[10px] text-slate-500">
              Represents {((metrics.totalShortages / (metrics.totalCurrentStock || 1)) * 100).toFixed(1)}% of total net holdings.
            </p>
          </div>
        </div>

        {/* Excess Stock / Recommendations panel */}
        <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between border-l-4 border-l-yellow-500">
          <div className="flex justify-between items-start">
            <div>
              <h4 className="text-sm font-semibold text-slate-300">Idle Excess Capital</h4>
              <p className="text-xs text-slate-400 mt-1">Overstocked units carrying carrying fees.</p>
            </div>
            <div className="p-2 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-yellow-400">
              <TrendingUp size={18} />
            </div>
          </div>
          <div className="my-4">
            <h2 className="text-5xl font-display font-black text-yellow-500">{metrics.totalExcessStock}</h2>
            <span className="text-xs text-slate-400">Units suitable for relocation</span>
          </div>
          <div className="flex items-center justify-between p-3 bg-slate-950/40 rounded-xl border border-slate-800/40 text-xs">
            <div className="flex items-center space-x-2 text-slate-300">
              <GitPullRequest size={14} className="text-indigo-400" />
              <span>{metrics.activeTransferRecommendations} Proposals</span>
            </div>
            <span className="font-semibold text-emerald-400">Est Savings: ₹{metrics.estimatedSavings.toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>

      {/* Chart Visualizations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="glass-panel p-6 rounded-2xl lg:col-span-2 h-[350px] flex flex-col">
          <h4 className="text-sm font-semibold text-slate-300 mb-4">Fulfillment Capacity Audit</h4>
          <div className="flex-1 relative">
            <Bar data={barChartData} options={barChartOptions} />
          </div>
        </div>

        <div className="glass-panel p-6 rounded-2xl h-[350px] flex flex-col">
          <h4 className="text-sm font-semibold text-slate-300 mb-4">Capital Cost Allocation</h4>
          <div className="flex-1 relative flex items-center justify-center">
            <Doughnut data={doughnutData} options={doughnutOptions} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
