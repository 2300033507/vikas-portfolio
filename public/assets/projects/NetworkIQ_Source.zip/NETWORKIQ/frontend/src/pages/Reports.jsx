import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Truck, 
  Activity, 
  Calendar, 
  Clock, 
  User,
  ExternalLink,
  X,
  TrendingDown
} from 'lucide-react';
import api from '../api';

const Reports = () => {
  const [transfers, setTransfers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  
  // Audit modal state
  const [showAuditModal, setShowAuditModal] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState(null);
  const [auditLogs, setAuditLogs] = useState([]);
  const [loadingAudit, setLoadingAudit] = useState(false);

  const fetchTransfers = async () => {
    setLoading(true);
    try {
      let res;
      if (statusFilter) {
        res = await api.get(`/api/transfers/status?status=${statusFilter}`);
      } else {
        res = await api.get('/api/transfers');
      }
      setTransfers(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransfers();
  }, [statusFilter]);

  const handleUpdateStatus = async (id, status) => {
    try {
      await api.put(`/api/transfers/${id}/status?status=${status}`);
      fetchTransfers();
      alert(`Transfer updated to status: ${status}`);
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update transfer status.');
    }
  };

  const handleOpenAudit = async (transfer) => {
    setSelectedTransfer(transfer);
    setShowAuditModal(true);
    setLoadingAudit(true);
    try {
      const res = await api.get(`/api/transfers/${transfer.id}/history`);
      setAuditLogs(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAudit(false);
    }
  };

  return (
    <div className="space-y-6 pb-10">
      {/* Filters and exports */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-300">Logistics Pipeline & Audits</h3>
          <p className="text-xs text-slate-400 mt-1">Track physical stock shipments and audit structural transaction trails.</p>
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-300 text-xs outline-none focus:border-indigo-500"
        >
          <option value="">All Transactions</option>
          <option value="SCHEDULED">Scheduled</option>
          <option value="IN_TRANSIT">In Transit</option>
          <option value="COMPLETED">Completed</option>
          <option value="CANCELLED">Cancelled</option>
        </select>
      </div>

      {/* Grid table */}
      <div className="glass-panel rounded-2xl overflow-hidden border border-slate-800/80">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="bg-slate-950/50 border-b border-slate-800/80 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                <th className="p-4">Transfer ID</th>
                <th className="p-4">SKU / Product</th>
                <th className="p-4">Source Hub</th>
                <th className="p-4">Destination Store</th>
                <th className="p-4 text-center">Quantity</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 text-right">Transit Cost</th>
                <th className="p-4 text-center">Logistics Controls</th>
                <th className="p-4 text-center">Auditing</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-xs text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="9" className="p-8 text-center text-slate-500">
                    Scanning transfer logs...
                  </td>
                </tr>
              ) : transfers.length === 0 ? (
                <tr>
                  <td colSpan="9" className="p-8 text-center text-slate-500">
                    No active inventory transfers scheduled. Approve recommendations to launch movements.
                  </td>
                </tr>
              ) : (
                transfers.map((item) => {
                  let statusBg = 'bg-slate-800 text-slate-400';
                  if (item.status === 'SCHEDULED') statusBg = 'bg-blue-500/10 text-blue-400 border border-blue-500/20';
                  if (item.status === 'IN_TRANSIT') statusBg = 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20';
                  if (item.status === 'COMPLETED') statusBg = 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/10';
                  if (item.status === 'CANCELLED') statusBg = 'bg-red-500/10 text-red-400 border border-red-500/20';

                  return (
                    <tr key={item.id} className="hover:bg-slate-800/20 transition-all duration-150">
                      <td className="p-4 font-mono font-bold text-slate-400">#TR-{item.id}</td>
                      <td className="p-4">
                        <div className="text-slate-200 font-semibold">{item.productName}</div>
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">{item.productSku}</div>
                      </td>
                      <td className="p-4 text-slate-300 font-medium">{item.sourceLocationName}</td>
                      <td className="p-4 text-slate-300 font-medium">{item.destinationLocationName}</td>
                      <td className="p-4 text-center font-bold text-slate-200">{item.quantity}</td>
                      <td className="p-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${statusBg}`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="p-4 text-right font-mono font-semibold text-emerald-400">₹{item.transferCost}</td>
                      <td className="p-4">
                        <div className="flex items-center justify-center space-x-1">
                          {item.status === 'SCHEDULED' && (
                            <button
                              onClick={() => handleUpdateStatus(item.id, 'IN_TRANSIT')}
                              className="px-2 py-1 bg-yellow-500/10 hover:bg-yellow-500 text-yellow-400 hover:text-slate-900 border border-yellow-500/30 rounded font-semibold text-[10px] transition-all"
                            >
                              Dispatch Ship
                            </button>
                          )}
                          {item.status === 'IN_TRANSIT' && (
                            <button
                              onClick={() => handleUpdateStatus(item.id, 'COMPLETED')}
                              className="px-2 py-1 bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-slate-900 border border-emerald-500/20 rounded font-semibold text-[10px] transition-all"
                            >
                              Mark Delivered
                            </button>
                          )}
                          {(item.status === 'SCHEDULED' || item.status === 'IN_TRANSIT') && (
                            <button
                              onClick={() => handleUpdateStatus(item.id, 'CANCELLED')}
                              className="px-2 py-1 bg-red-500/10 hover:bg-red-600 text-red-400 hover:text-slate-100 border border-red-500/20 rounded font-semibold text-[10px] transition-all"
                            >
                              Cancel
                            </button>
                          )}
                          {(item.status === 'COMPLETED' || item.status === 'CANCELLED') && (
                            <span className="text-[10px] text-slate-600 italic">Locked</span>
                          )}
                        </div>
                      </td>
                      <td className="p-4">
                        <button
                          onClick={() => handleOpenAudit(item)}
                          className="flex items-center justify-center space-x-1 text-[10px] text-indigo-400 hover:text-indigo-300 font-semibold mx-auto transition-all"
                        >
                          <ExternalLink size={12} />
                          <span>Audit Trail</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Audit Modal */}
      {showAuditModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-lg glass-panel p-6 rounded-2xl glow-border-indigo">
            <div className="flex justify-between items-center mb-6 border-b border-slate-900/60 pb-4">
              <div>
                <h3 className="text-base font-display font-bold text-slate-200">Transaction Audit Trail</h3>
                <p className="text-[10px] text-indigo-400 font-mono mt-0.5">Transfer Ref: #TR-{selectedTransfer.id}</p>
              </div>
              <button onClick={() => setShowAuditModal(false)} className="p-1 hover:bg-slate-800 rounded-lg text-slate-400"><X size={16} /></button>
            </div>

            {loadingAudit ? (
              <div className="p-8 text-center text-slate-500 text-xs">Querying audit logs history...</div>
            ) : auditLogs.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">No audit logs found for this transaction.</div>
            ) : (
              <div className="relative border-l-2 border-slate-800/80 pl-6 ml-4 my-4 space-y-6">
                {auditLogs.map((log) => {
                  let actColor = 'text-slate-400';
                  if (log.action === 'APPROVED') actColor = 'text-indigo-400';
                  if (log.action === 'IN_TRANSIT') actColor = 'text-yellow-400';
                  if (log.action === 'COMPLETED') actColor = 'text-emerald-400';
                  if (log.action === 'CANCELLED') actColor = 'text-red-400';

                  return (
                    <div key={log.id} className="relative">
                      {/* Timeline dot */}
                      <span className="absolute -left-[31px] top-1 h-2 w-2 rounded-full bg-slate-800 border-2 border-slate-950"></span>
                      
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2 text-xs">
                          <span className={`font-mono font-bold uppercase ${actColor}`}>{log.action}</span>
                          <span className="text-[10px] text-slate-500">•</span>
                          <span className="text-[10px] text-slate-500 flex items-center space-x-1">
                            <Clock size={10} />
                            <span>{new Date(log.createdAt).toLocaleString()}</span>
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-relaxed font-medium">{log.description}</p>
                        {log.performedBy && (
                          <span className="text-[9px] text-slate-500 flex items-center space-x-1">
                            <User size={9} />
                            <span>Performed by: <b>{log.performedBy.username}</b></span>
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Reports;
