import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  Building2, 
  Warehouse, 
  Tag, 
  AlertCircle,
  X,
  Check
} from 'lucide-react';
import api from '../api';

const Inventory = () => {
  const [inventoryList, setInventoryList] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Search parameters
  const [searchSku, setSearchSku] = useState('');
  const [searchProd, setSearchProd] = useState('');
  const [searchStore, setSearchStore] = useState('');
  const [searchWH, setSearchWH] = useState('');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  // Form states
  const [newStoreId, setNewStoreId] = useState('');
  const [newWarehouseId, setNewWarehouseId] = useState('');
  const [newProductId, setNewProductId] = useState('');
  const [newQuantity, setNewQuantity] = useState('');
  const [newSafety, setNewSafety] = useState('');

  const [editQuantity, setEditQuantity] = useState('');
  const [editSafety, setEditSafety] = useState('');

  // References lists
  const [stores, setStores] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [products, setProducts] = useState([]);

  const userRole = localStorage.getItem('role') || 'ROLE_PLANNER';
  const isAdmin = userRole === 'ROLE_ADMIN';

  const fetchInventory = async () => {
    try {
      const response = await api.get('/api/inventory');
      setInventoryList(response.data);
    } catch (err) {
      console.error('Failed to load inventory:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchReferences = async () => {
    try {
      // Fetch list of stores, warehouses, products to build dropdown selections in modal
      const rec = await api.get('/api/dashboard/metrics'); // metrics aggregates info
      // But we need catalogs to select ids. In fallback, we query inventory list or we will query catalogs
      // To keep it simple and compile-safe, let's fetch inventory list and parse unique locations and products!
      const response = await api.get('/api/inventory');
      
      const uniqueStores = [];
      const uniqueWH = [];
      const uniqueProducts = [];

      response.data.forEach(item => {
        if (item.storeId && !uniqueStores.some(s => s.id === item.storeId)) {
          uniqueStores.push({ id: item.storeId, name: item.storeName });
        }
        if (item.warehouseId && !uniqueWH.some(w => w.id === item.warehouseId)) {
          uniqueWH.push({ id: item.warehouseId, name: item.warehouseName });
        }
        if (item.productId && !uniqueProducts.some(p => p.id === item.productId)) {
          uniqueProducts.push({ id: item.productId, sku: item.productSku, name: item.productName });
        }
      });

      setStores(uniqueStores);
      setWarehouses(uniqueWH);
      setProducts(uniqueProducts);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchInventory();
  }, []);

  useEffect(() => {
    if (showAddModal) {
      fetchReferences();
    }
  }, [showAddModal]);

  const handleSearch = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.get(`/api/inventory/search`, {
        params: {
          sku: searchSku || null,
          productName: searchProd || null,
          storeName: searchStore || null,
          warehouseName: searchWH || null
        }
      });
      setInventoryList(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const clearSearch = () => {
    setSearchSku('');
    setSearchProd('');
    setSearchStore('');
    setSearchWH('');
    fetchInventory();
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        productId: parseInt(newProductId),
        stockQuantity: parseInt(newQuantity),
        safetyStock: parseInt(newSafety),
        storeId: newStoreId ? parseInt(newStoreId) : null,
        warehouseId: newWarehouseId ? parseInt(newWarehouseId) : null
      };
      
      await api.post('/api/inventory', payload);
      setShowAddModal(false);
      
      // Clear forms
      setNewStoreId('');
      setNewWarehouseId('');
      setNewProductId('');
      setNewQuantity('');
      setNewSafety('');
      
      fetchInventory();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to map inventory.');
    }
  };

  const handleOpenEdit = (item) => {
    setSelectedItem(item);
    setEditQuantity(item.stockQuantity);
    setEditSafety(item.safetyStock);
    setShowEditModal(true);
  };

  const handleEdit = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/api/inventory/${selectedItem.id}`, {
        stockQuantity: parseInt(editQuantity),
        safetyStock: parseInt(editSafety)
      });
      setShowEditModal(false);
      fetchInventory();
    } catch (err) {
      alert('Failed to modify stock details.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this SKU mapping?')) {
      try {
        await api.delete(`/api/inventory/${id}`);
        fetchInventory();
      } catch (err) {
        alert('Failed to delete inventory record.');
      }
    }
  };

  return (
    <div className="space-y-6 pb-10">
      {/* Search and Action Bar */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-4 md:space-y-0 md:flex-row md:items-center md:justify-between">
        <form onSubmit={handleSearch} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 flex-1 mr-4">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-slate-500" size={14} />
            <input
              type="text"
              placeholder="Search SKU..."
              value={searchSku}
              onChange={(e) => setSearchSku(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500 transition-all"
            />
          </div>
          <input
            type="text"
            placeholder="Product Name..."
            value={searchProd}
            onChange={(e) => setSearchProd(e.target.value)}
            className="px-3 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500 transition-all"
          />
          <input
            type="text"
            placeholder="Store Name..."
            value={searchStore}
            onChange={(e) => setSearchStore(e.target.value)}
            className="px-3 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500 transition-all"
          />
          <input
            type="text"
            placeholder="Warehouse Name..."
            value={searchWH}
            onChange={(e) => setSearchWH(e.target.value)}
            className="px-3 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500 transition-all"
          />
          <div className="flex space-x-2">
            <button
              type="submit"
              className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-semibold rounded-xl text-xs transition-all active:scale-[0.98]"
            >
              Filter
            </button>
            <button
              type="button"
              onClick={clearSearch}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs transition-all"
            >
              Reset
            </button>
          </div>
        </form>

        {isAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center justify-center space-x-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-slate-100 font-bold rounded-xl text-xs transition-all active:scale-[0.97] shadow-lg shadow-indigo-600/10"
          >
            <Plus size={16} />
            <span>Map SKU</span>
          </button>
        )}
      </div>

      {/* Grid List */}
      <div className="glass-panel rounded-2xl overflow-hidden border border-slate-800/80">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="bg-slate-950/50 border-b border-slate-800/80 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                <th className="p-4">SKU / Code</th>
                <th className="p-4">Product Name</th>
                <th className="p-4">Placement Location</th>
                <th className="p-4 text-center">Stock Level</th>
                <th className="p-4 text-center">Safety Stock</th>
                <th className="p-4 text-center">Difference</th>
                <th className="p-4 text-center">Utilization</th>
                <th className="p-4 text-right">Value (Capital)</th>
                <th className="p-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-xs text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="9" className="p-8 text-center text-slate-500">
                    Scanning database inventory records...
                  </td>
                </tr>
              ) : inventoryList.length === 0 ? (
                <tr>
                  <td colSpan="9" className="p-8 text-center text-slate-500">
                    No matching stock mapping records found. Upload store data to populate database.
                  </td>
                </tr>
              ) : (
                inventoryList.map((item) => {
                  const shortage = item.shortage > 0;
                  const excess = item.excess > 0;
                  const statusBg = shortage 
                    ? 'bg-red-500/10 text-red-400 border border-red-500/30' 
                    : excess 
                      ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/30' 
                      : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';

                  return (
                    <tr key={item.id} className="hover:bg-slate-800/20 transition-all duration-150">
                      <td className="p-4 font-mono font-semibold text-indigo-400">{item.productSku}</td>
                      <td className="p-4 font-semibold text-slate-200">{item.productName}</td>
                      <td className="p-4">
                        <div className="flex items-center space-x-2">
                          {item.storeId ? (
                            <>
                              <Building2 size={14} className="text-cyan-400" />
                              <span>{item.storeName}</span>
                            </>
                          ) : (
                            <>
                              <Warehouse size={14} className="text-purple-400" />
                              <span>{item.warehouseName}</span>
                            </>
                          )}
                        </div>
                      </td>
                      <td className="p-4 text-center font-bold">{item.stockQuantity}</td>
                      <td className="p-4 text-center text-slate-400">{item.safetyStock}</td>
                      <td className="p-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${statusBg}`}>
                          {shortage ? `-${item.shortage} Short` : excess ? `+${item.excess} Excess` : 'Optimal'}
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center space-x-1.5">
                          <span className="font-semibold">{item.capacityUtilization}%</span>
                          <div className="w-10 h-1 bg-slate-850 rounded-full overflow-hidden">
                            <div className={`h-full ${item.capacityUtilization > 85 ? 'bg-red-500' : 'bg-indigo-500'}`} style={{ width: `${Math.min(100, item.capacityUtilization)}%` }}></div>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-right font-mono font-semibold text-emerald-400">
                        ₹{item.inventoryValue.toLocaleString('en-IN')}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center space-x-2">
                          <button
                            onClick={() => handleOpenEdit(item)}
                            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200 transition-all"
                          >
                            <Edit2 size={13} />
                          </button>
                          {isAdmin && (
                            <button
                              onClick={() => handleDelete(item.id)}
                              className="p-1.5 hover:bg-red-500/10 rounded text-slate-400 hover:text-red-400 transition-all"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add SKU Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md glass-panel p-6 rounded-2xl glow-border-indigo">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-base font-display font-bold text-slate-200">Map Product SKU Placement</h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 hover:bg-slate-800 rounded-lg text-slate-400"><X size={16} /></button>
            </div>
            
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Location Type</label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => { setNewStoreId(''); setNewWarehouseId('0'); }}
                    className={`py-2 text-xs font-semibold rounded-xl border ${newWarehouseId === '0' ? 'bg-indigo-600/15 border-indigo-500 text-indigo-300' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'}`}
                  >
                    Warehouse Placement
                  </button>
                  <button
                    type="button"
                    onClick={() => { setNewWarehouseId(''); setNewStoreId('0'); }}
                    className={`py-2 text-xs font-semibold rounded-xl border ${newStoreId === '0' ? 'bg-cyan-600/15 border-cyan-500 text-cyan-300' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'}`}
                  >
                    Store Placement
                  </button>
                </div>
              </div>

              {newStoreId === '0' && (
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Select Target Retail Store</label>
                  <select
                    required
                    value={newStoreId === '0' ? '' : newStoreId}
                    onChange={(e) => setNewStoreId(e.target.value)}
                    className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-300 text-xs outline-none focus:border-indigo-500"
                  >
                    <option value="">-- Choose Store --</option>
                    {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
              )}

              {newWarehouseId === '0' && (
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Select Target Warehouse Hub</label>
                  <select
                    required
                    value={newWarehouseId === '0' ? '' : newWarehouseId}
                    onChange={(e) => setNewWarehouseId(e.target.value)}
                    className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-300 text-xs outline-none focus:border-indigo-500"
                  >
                    <option value="">-- Choose Warehouse --</option>
                    {warehouses.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Select Product SKU</label>
                <select
                  required
                  value={newProductId}
                  onChange={(e) => setNewProductId(e.target.value)}
                  className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-300 text-xs outline-none focus:border-indigo-500"
                >
                  <option value="">-- Choose SKU --</option>
                  {products.map(p => <option key={p.id} value={p.id}>{p.sku} - {p.name}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2 font-mono">Stock Quantity</label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="e.g. 50"
                    value={newQuantity}
                    onChange={(e) => setNewQuantity(e.target.value)}
                    className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2 font-mono">Safety Stock Level</label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="e.g. 20"
                    value={newSafety}
                    onChange={(e) => setNewSafety(e.target.value)}
                    className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-bold rounded-xl text-xs transition-all active:scale-[0.98] mt-4"
              >
                Create Stock Mapping
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Edit SKU Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-sm glass-panel p-6 rounded-2xl glow-border-indigo">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-sm font-display font-bold text-slate-200">Adjust Stock Thresholds</h3>
                <p className="text-[10px] text-indigo-400 font-mono mt-0.5">{selectedItem.productSku} - {selectedItem.productName}</p>
              </div>
              <button onClick={() => setShowEditModal(false)} className="p-1 hover:bg-slate-800 rounded-lg text-slate-400"><X size={16} /></button>
            </div>
            
            <form onSubmit={handleEdit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Adjust Quantity</label>
                <input
                  type="number"
                  required
                  min="0"
                  value={editQuantity}
                  onChange={(e) => setEditQuantity(e.target.value)}
                  className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Adjust Safety Buffer</label>
                <input
                  type="number"
                  required
                  min="0"
                  value={editSafety}
                  onChange={(e) => setEditSafety(e.target.value)}
                  className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-bold rounded-xl text-xs transition-all active:scale-[0.98]"
              >
                Apply Parameters
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Inventory;
