import React, { useState, useEffect } from 'react';
import { 
  LineChart, 
  RefreshCw, 
  Search, 
  TrendingUp, 
  CheckCircle,
  Building2
} from 'lucide-react';
import api from '../api';

const Forecast = () => {
  const [forecasts, setForecasts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusMessage, setStatusMessage] = useState('');

  const fetchForecasts = async () => {
    try {
      const response = await api.get('/api/forecast');
      setForecasts(response.data);
    } catch (err) {
      console.error('Failed to load forecasts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchForecasts();
  }, []);

  const handleTriggerForecast = async () => {
    setTriggering(true);
    setStatusMessage('');
    try {
      const res = await api.post('/api/forecast/trigger');
      setStatusMessage(res.data.message || 'Forecasting completed successfully!');
      fetchForecasts();
    } catch (err) {
      console.error(err);
      setStatusMessage('Forecasting failed. Make sure ML microservice is configured.');
    } finally {
      setTriggering(false);
    }
  };

  const filteredForecasts = forecasts.filter(f => 
    f.productSku.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.storeName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-10">
      {/* Trigger section */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-4 md:space-y-0 md:flex-row md:items-center md:justify-between border-l-4 border-l-cyan-500">
        <div>
          <h3 className="text-sm font-semibold text-slate-300">Run Demand Forecasting Model</h3>
          <p className="text-xs text-slate-400 mt-1">
            Analyze historical sales records using XGBoost models to predict SKU quantities for locations.
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {statusMessage && (
            <span className="text-xs text-emerald-400 font-semibold flex items-center space-x-1">
              <CheckCircle size={14} />
              <span>{statusMessage}</span>
            </span>
          )}
          <button
            onClick={handleTriggerForecast}
            disabled={triggering}
            className="flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-cyan-600 to-indigo-650 hover:from-cyan-500 hover:to-indigo-550 disabled:opacity-50 text-slate-100 font-bold rounded-xl text-xs transition-all active:scale-[0.97] shadow-lg shadow-cyan-600/10"
          >
            {triggering ? (
              <>
                <RefreshCw size={14} className="animate-spin" />
                <span>Running XGBoost...</span>
              </>
            ) : (
              <>
                <TrendingUp size={14} />
                <span>Trigger Forecasts</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Grid search bar */}
      <div className="glass-panel p-4 rounded-xl max-w-md">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={14} />
          <input
            type="text"
            placeholder="Search SKU or Store..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 text-xs outline-none focus:border-indigo-500 transition-all"
          />
        </div>
      </div>

      {/* Forecast list */}
      <div className="glass-panel rounded-2xl overflow-hidden border border-slate-800/80">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="bg-slate-950/50 border-b border-slate-800/80 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                <th className="p-4">SKU Code</th>
                <th className="p-4">Product Name</th>
                <th className="p-4">Retail Location</th>
                <th className="p-4 text-center">Prediction Target Date</th>
                <th className="p-4 text-center">Forecasted Qty (Units)</th>
                <th className="p-4 text-center">Confidence Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40 text-xs text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-slate-500">
                    Retrieving predicted sales trends...
                  </td>
                </tr>
              ) : filteredForecasts.length === 0 ? (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-slate-500">
                    No forecast predictions available. Trigger forecasting above to run predictions.
                  </td>
                </tr>
              ) : (
                filteredForecasts.map((item) => {
                  const conf = item.confidenceScore * 100;
                  const confColor = conf >= 85 ? 'text-emerald-400' : conf >= 75 ? 'text-indigo-400' : 'text-slate-400';

                  return (
                    <tr key={item.id} className="hover:bg-slate-800/20 transition-all duration-150">
                      <td className="p-4 font-mono font-semibold text-indigo-400">{item.productSku}</td>
                      <td className="p-4 font-semibold text-slate-200">{item.productName}</td>
                      <td className="p-4">
                        <div className="flex items-center space-x-2">
                          <Building2 size={14} className="text-cyan-400" />
                          <span>{item.storeName}</span>
                        </div>
                      </td>
                      <td className="p-4 text-center font-semibold text-slate-400">
                        {new Date(item.forecastDate).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                      </td>
                      <td className="p-4 text-center font-bold text-slate-200">{item.quantity}</td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center space-x-2">
                          <span className={`font-semibold font-mono ${confColor}`}>{conf.toFixed(0)}%</span>
                          <div className="w-12 h-1 bg-slate-850 rounded-full overflow-hidden">
                            <div className={`h-full ${conf >= 85 ? 'bg-emerald-500' : 'bg-indigo-500'}`} style={{ width: `${conf}%` }}></div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Forecast;
