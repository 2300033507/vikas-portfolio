import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BrainCircuit, ShieldAlert, ArrowRight, Lock, User, Mail, UserPlus, CheckCircle } from 'lucide-react';
import api from '../api';

const Login = () => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('ROLE_PLANNER');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem('token')) {
      navigate('/');
    }
  }, [navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const response = await api.post('/api/auth/login', { username, password });
      const { token, role: userRole, email: userEmail } = response.data;
      
      localStorage.setItem('token', token);
      localStorage.setItem('username', response.data.username);
      localStorage.setItem('email', userEmail);
      localStorage.setItem('role', userRole);

      navigate('/');
    } catch (err) {
      console.error(err);
      setError(
        err.response?.data?.message || 
        'Invalid credentials. Please verify your username and password.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      await api.post('/api/auth/register', { username, email, password, role });
      setSuccess('Account registered successfully! You can now log in.');
      setIsRegistering(false);
      // Reset fields
      setPassword('');
    } catch (err) {
      console.error(err);
      setError(
        err.response?.data?.message || 
        'Registration failed. Please make sure details are correct.'
      );
    } finally {
      setLoading(false);
    }
  };

  const prefillCredentials = (userType) => {
    if (userType === 'admin') {
      setUsername('admin');
      setPassword('admin123');
    } else {
      setUsername('planner');
      setPassword('admin123');
    }
    setIsRegistering(false);
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-[#020617] overflow-hidden px-4">
      {/* Background Decorative Glow Circles */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-indigo-500/10 blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-purple-500/10 blur-[120px] pointer-events-none"></div>
      
      <div className="w-full max-w-md glass-panel p-8 rounded-2xl glow-border-indigo relative z-10">
        {/* Brand */}
        <div className="flex flex-col items-center mb-6">
          <div className="p-3.5 bg-indigo-600/20 border border-indigo-500/40 rounded-xl shadow-[0_0_15px_rgba(99,102,241,0.25)] mb-3">
            <BrainCircuit className="text-indigo-400 animate-pulse" size={32} />
          </div>
          <h2 className="font-display font-bold text-2xl text-slate-100 tracking-wider">
            NETWORKIQ
          </h2>
          <p className="text-xs text-slate-400 mt-1 uppercase tracking-widest text-center">
            {isRegistering ? 'Create Account' : 'AI Inventory Optimization Portal'}
          </p>
        </div>

        {/* Error panel */}
        {error && (
          <div className="mb-4 flex items-start space-x-2.5 p-3.5 bg-red-500/10 border border-red-500/30 rounded-xl text-xs text-red-400">
            <ShieldAlert size={16} className="flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Success panel */}
        {success && (
          <div className="mb-4 flex items-start space-x-2.5 p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-400">
            <CheckCircle size={16} className="flex-shrink-0 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        {isRegistering ? (
          /* Sign Up Form */
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Username
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-2.5 text-slate-500" size={16} />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Choose username"
                  className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-2.5 text-slate-500" size={16} />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter email address"
                  className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-2.5 text-slate-500" size={16} />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create password"
                  className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Role Permission
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-350 outline-none focus:border-indigo-500 text-xs"
              >
                <option value="ROLE_PLANNER">Retail Planner</option>
                <option value="ROLE_ADMIN">System Administrator</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center space-x-2 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-550 text-slate-100 font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-indigo-600/20 active:scale-[0.98] disabled:opacity-50 text-xs"
            >
              <UserPlus size={16} />
              <span>{loading ? 'Registering Account...' : 'Register Account'}</span>
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => { setIsRegistering(false); setError(''); }}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold transition-all"
              >
                Already have an account? Sign In
              </button>
            </div>
          </form>
        ) : (
          /* Sign In Form */
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Username
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-2.5 text-slate-500" size={16} />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter username"
                  className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-2.5 text-slate-500" size={16} />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center space-x-2 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-indigo-600/20 active:scale-[0.98] disabled:opacity-50 text-xs"
            >
              <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
              {!loading && <ArrowRight size={16} />}
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => { setIsRegistering(true); setError(''); }}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold transition-all"
              >
                New to the platform? Register Account
              </button>
            </div>
          </form>
        )}

        {/* Seed helper prefill links */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <p className="text-[10px] text-slate-500 uppercase tracking-wider text-center mb-2.5">
            Quick-fill seed credentials
          </p>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => prefillCredentials('admin')}
              className="py-1.5 bg-slate-900/60 hover:bg-indigo-600/10 border border-slate-800 hover:border-indigo-500/40 text-slate-400 hover:text-indigo-400 rounded-lg text-[10px] font-medium transition-all"
            >
              System Admin
            </button>
            <button
              onClick={() => prefillCredentials('planner')}
              className="py-1.5 bg-slate-900/60 hover:bg-purple-600/10 border border-slate-800 hover:border-purple-500/40 text-slate-400 hover:text-purple-400 rounded-lg text-[10px] font-medium transition-all"
            >
              Retail Planner
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
