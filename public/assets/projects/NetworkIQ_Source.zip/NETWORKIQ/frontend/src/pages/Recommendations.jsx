import React, { useState, useEffect } from 'react';
import { 
  GitPullRequest, 
  RefreshCw, 
  ArrowRight, 
  Coins, 
  Scale, 
  Clock, 
  Brain, 
  Check, 
  X, 
  ChevronDown, 
  ChevronUp, 
  MessageSquare,
  Percent,
  Edit3
} from 'lucide-react';
import api from '../api';

const Recommendations = () => {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [optimizing, setOptimizing] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  
  // Expand logs state
  const [expandedId, setExpandedId] = useState(null);

  // Modification inline state
  const [editingId, setEditingId] = useState(null);
  const [editQty, setEditQty] = useState('');

  const fetchRecommendations = async () => {
    try {
      const response = await api.get('/api/recommendations/pending');
      setRecommendations(response.data);
    } catch (err) {
      console.error('Failed to fetch recommendations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecommendations();
  }, []);

  const handleOptimize = async () => {
    setOptimizing(true);
    setStatusMessage('');
    try {
      const res = await api.post('/api/recommendations/trigger');
      setStatusMessage(res.data.message || 'Optimization run completed successfully!');
      fetchRecommendations();
    } catch (err) {
      console.error(err);
      setStatusMessage('Optimization sweep failed. Verify agent microservice status.');
    } finally {
      setOptimizing(false);
    }
  };

  const handleAction = async (id, status, customQty = null) => {
    try {
      const payload = {
        status,
        quantity: customQty ? parseInt(customQty) : null
      };
      
      await api.post(`/api/recommendations/${id}/approve`, payload);
      setEditingId(null);
      setEditQty('');
      fetchRecommendations();
      alert(`Transfer recommendation successfully processed as: ${status}`);
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to submit approval choice.');
    }
  };

  const toggleLogs = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const startEdit = (rec) => {
    setEditingId(rec.id);
    setEditQty(rec.quantity);
  };

  return (
    <div className="space-y-6 pb-10">
      {/* Trigger Board */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-4 md:space-y-0 md:flex-row md:items-center md:justify-between border-l-4 border-l-indigo-500">
        <div>
          <h3 className="text-sm font-semibold text-slate-300">Run Cooperating Multi-Agent Optimization</h3>
          <p className="text-xs text-slate-400 mt-1">
            Initiate cooperative agent negotiations (Demand, Capacity, Cost, and Review nodes) to resolve network deficits.
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {statusMessage && (
            <span className="text-xs text-indigo-400 font-semibold">{statusMessage}</span>
          )}
          <button
            onClick={handleOptimize}
            disabled={optimizing}
            className="flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-650 hover:from-indigo-500 hover:to-purple-550 disabled:opacity-50 text-slate-100 font-bold rounded-xl text-xs transition-all active:scale-[0.97] shadow-lg shadow-indigo-600/10 animate-pulse"
          >
            {optimizing ? (
              <>
                <RefreshCw size={14} className="animate-spin" />
                <span>Negotiating Graph Nodes...</span>
              </>
            ) : (
              <>
                <Brain size={14} />
                <span>Run Optimization</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Grid list recommendations */}
      <div className="space-y-4">
        {loading ? (
          <div className="glass-panel p-8 text-center text-slate-500">
            Querying pending inventory transfer recommendations...
          </div>
        ) : recommendations.length === 0 ? (
          <div className="glass-panel p-8 text-center text-slate-500">
            No pending transfer proposals awaiting approval. Click "Run Optimization" above to analyze the network.
          </div>
        ) : (
          recommendations.map((rec) => {
            const isExpanded = expandedId === rec.id;
            const isEditing = editingId === rec.id;

            // Parse reasoning logs
            let logs = {};
            try {
              if (rec.reasoning) {
                logs = JSON.parse(rec.reasoning);
              }
            } catch (e) {
              console.warn('Reasoning format error', e);
            }

            const source = rec.sourceStoreName || rec.sourceWarehouseName;
            const destination = rec.destinationStoreName || rec.destinationWarehouseName;

            return (
              <div key={rec.id} className="glass-panel rounded-2xl overflow-hidden border border-slate-800/80 hover:border-slate-700/60 transition-all duration-200">
                {/* Main Card Summary */}
                <div className="p-6 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                  {/* Left: Move Info */}
                  <div className="space-y-3 flex-1">
                    <div className="flex items-center space-x-2 text-xs">
                      <span className="font-mono font-bold text-indigo-400">{rec.productSku}</span>
                      <span className="text-slate-500">•</span>
                      <span className="font-semibold text-slate-200">{rec.productName}</span>
                    </div>

                    <div className="flex items-center space-x-3 text-sm font-semibold">
                      <span className="text-slate-300">{source}</span>
                      <ArrowRight size={14} className="text-slate-500" />
                      <span className="text-slate-100">{destination}</span>
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed font-medium">
                      {rec.businessReason}
                    </p>
                  </div>

                  {/* Center: Financial and Time Metrics */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-950/40 p-4 rounded-xl border border-slate-900/60 lg:w-[480px]">
                    <div>
                      <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block">Quantity</span>
                      {isEditing ? (
                        <input
                          type="number"
                          min="1"
                          max={rec.quantity}
                          value={editQty}
                          onChange={(e) => setEditQty(e.target.value)}
                          className="w-16 mt-1 px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded font-bold text-indigo-400 outline-none text-xs"
                        />
                      ) : (
                        <span className="text-sm font-bold text-slate-200 block mt-1">{rec.quantity} Units</span>
                      )}
                    </div>

                    <div>
                      <span className="flex items-center space-x-1 text-[9px] text-slate-500 font-bold uppercase tracking-wider block">
                        <Coins size={10} className="text-indigo-400" />
                        <span>Transfer Cost</span>
                      </span>
                      <span className="text-xs font-semibold text-slate-300 block mt-1">₹{rec.transferCost}</span>
                    </div>

                    <div>
                      <span className="flex items-center space-x-1 text-[9px] text-slate-500 font-bold uppercase tracking-wider block">
                        <Scale size={10} className="text-emerald-400" />
                        <span>Holding Saved</span>
                      </span>
                      <span className="text-xs font-semibold text-emerald-400 block mt-1">₹{rec.holdingCostSaved}</span>
                    </div>

                    <div>
                      <span className="flex items-center space-x-1 text-[9px] text-slate-500 font-bold uppercase tracking-wider block">
                        <Clock size={10} className="text-cyan-400" />
                        <span>Delivery Speed</span>
                      </span>
                      <span className="text-xs font-semibold text-cyan-400 block mt-1">+{rec.deliveryImprovement} Days</span>
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex lg:flex-col sm:flex-row items-center gap-2 lg:w-40 justify-end">
                    {isEditing ? (
                      <div className="flex space-x-1 w-full justify-end">
                        <button
                          onClick={() => handleAction(rec.id, 'APPROVED', editQty)}
                          className="p-2 bg-emerald-600 hover:bg-emerald-500 text-slate-100 rounded-lg text-xs font-semibold flex items-center space-x-1 transition-all"
                        >
                          <Check size={14} />
                          <span>Apply</span>
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-all"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <>
                        <button
                          onClick={() => handleAction(rec.id, 'APPROVED')}
                          className="w-full py-2 bg-emerald-600/10 border border-emerald-500/30 hover:bg-emerald-600 text-emerald-400 hover:text-slate-100 text-xs font-bold rounded-xl transition-all flex items-center justify-center space-x-1.5 active:scale-[0.98]"
                        >
                          <Check size={14} />
                          <span>Approve</span>
                        </button>
                        <button
                          onClick={() => handleAction(rec.id, 'REJECTED')}
                          className="w-full py-2 bg-red-500/10 border border-red-500/30 hover:bg-red-600 text-red-400 hover:text-slate-100 text-xs font-bold rounded-xl transition-all flex items-center justify-center space-x-1.5 active:scale-[0.98]"
                        >
                          <X size={14} />
                          <span>Reject</span>
                        </button>
                        <button
                          onClick={() => startEdit(rec)}
                          className="w-full py-2 bg-slate-800 hover:bg-slate-750 hover:text-indigo-400 text-slate-400 text-xs font-semibold rounded-xl border border-slate-800 transition-all flex items-center justify-center space-x-1.5"
                        >
                          <Edit3 size={13} />
                          <span>Modify Qty</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* Agent Logs Toggle */}
                <div className="px-6 py-2 border-t border-slate-900/60 bg-slate-950/20 flex items-center justify-between text-[11px] text-slate-500 font-semibold">
                  <span className="flex items-center space-x-1.5">
                    <Percent size={12} className="text-indigo-400" />
                    <span>Agent Recommendation Confidence Score: <b className="text-indigo-300">{(rec.confidenceScore * 100).toFixed(0)}%</b></span>
                  </span>
                  
                  <button
                    onClick={() => toggleLogs(rec.id)}
                    className="flex items-center space-x-1 hover:text-slate-300 text-indigo-400 transition-all"
                  >
                    <MessageSquare size={12} />
                    <span>{isExpanded ? "Hide Agent Explanations" : "Inspect Multi-Agent Negotiations"}</span>
                    {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                  </button>
                </div>

                {/* Expandable Agent Reasoning details */}
                {isExpanded && (
                  <div className="bg-slate-950 border-t border-slate-900 p-6 space-y-4 font-mono text-[10px] text-slate-400">
                    <h5 className="text-[11px] font-display font-bold text-slate-300 mb-2">LangGraph Negotiation Console Logs</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {Object.entries(logs).map(([agent, text]) => {
                        const friendlyAgentName = agent.replace('Agent', ' Agent').replace(/^[a-z]/, c => c.toUpperCase());
                        return (
                          <div key={agent} className="p-3 bg-slate-900/50 rounded-xl border border-slate-850 space-y-1.5">
                            <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest">{friendlyAgentName}</span>
                            <p className="text-slate-400 leading-relaxed text-[10px]">{text}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Recommendations;
